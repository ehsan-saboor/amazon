<?php include './components/header.php'; ?>
<section class="main-banner serv-banner ecom-bnr custom-banner-10">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <div class="mbnr-left-txt">
                        <h1 class=" wow fadeInUp" data-wow-duration="2s">Improve Conversion Rates With E-Commerce
                            Marketing Services</h1>
                        <p class=" wow fadeInUp" data-wow-duration="3s">Running an online shop is a constant effort. We
                            are the leading e-commerce PPC marketing agency that allows you to reach unparalleled
                            e-commerce marketing methods to enhance your existing business operations. Our e-commerce
                            marketing provides premium alternatives for owners and customers both. We offer: </p>
                        <div class="banner-ul">
                            <ul class=" wow fadeInUp" data-wow-duration="2s">
                                <li><i class="fa fa-check-circle" aria-hidden="true"></i>OpenCart e-commerce development
                                </li>
                                <li><i class="fa fa-check-circle" aria-hidden="true"></i>Drupal commerce development
                                </li>
                                <li><i class="fa fa-check-circle" aria-hidden="true"></i>OS commerce development
                                    services</li>
                                <li><i class="fa fa-check-circle" aria-hidden="true"></i>Woo-commerce e-commerce
                                    development</li>
                            </ul>


                        </div>
                        <div class="banner-btn btn-st  wow fadeInUp" data-wow-duration="3s">
                            <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();"
                                data-wow-duration="4s">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
                <div class="col-sm-7">
                    <div class="banner-side-img  wow zoomIn" data-wow-duration="2s">
                        <img src="images/ecom-bnr-side-img.png">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-sec-two">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-5">
                        <div class="services-pro-img">
                            <img class=" wow zoomIn" data-wow-duration="2s" src="images/ecom-store-inner-img-new.png">

                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="about-who-txt">
                            <h2 class="wow fadeInLeft" data-wow-duration="2s">Boost The Selling Process</h2>
                            <p class="wow fadeInLeft" data-wow-duration="3s">Our e-commerce marketing involves digital
                                promotion strategies like PPC, SEO, social media management, and different concepts to
                                improve the brand's online visibility and website traffic. We assist you with social
                                media marketing services online, e-commerce email marketing companies, Magento
                                e-commerce development services, and more.</p>
                        </div>
                        <div class="services-about-ul">
                            <ul>
                                <li class="wow fadeInLeft" data-wow-duration="2s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Establish a concrete identity online</li>
                                <li class="wow fadeInLeft" data-wow-duration="3s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Rapid response to consumers</li>
                                <li class="wow fadeInLeft" data-wow-duration="4s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Affordable advertising & marketing</li>
                                <li class="wow fadeInLeft" data-wow-duration="2s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Flexibility for potential shoppers</li>
                            </ul>

                        </div>
                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInLeft" data-wow-duration="2s">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st  w callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_market_sec">
        <div class="">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">Professional E-Commerce Marketing Company</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">We offer the best e-commerce marketing services
                            to allow you to keep track of demographic data and online happenings of visitors and
                            customers.</p>
                    </div>
                </div>
            </div>
            <div class="amazon_market_slider">
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img1.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img2.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img3.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img4.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img5.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img6.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img7.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img8.jpg"></div>
            </div>
        </div>
    </section>
    <section class="why-choose bdr-btm-sec">
        <div class="container">
            <div class="row">
                <div class="why-col-lft why-col-lft-heading">
                    <h3 class="wow fadeInLeft" data-wow-delay="380ms">Why Hire Our E-commerce </h3>
                    <h2 class="wow fadeInLeft" data-wow-delay="400ms">Marketing Agency Online?</h2>
                    <p class="wow fadeInLeft" data-wow-delay="410ms">As a professional e-commerce marketing company, we
                        facilitate clients with online e-commerce marketing services to discover resources and increase
                        your value among buyers.</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="why-col-lft">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-1.png">
                                    <div class="why-txt">
                                        <h5>Affordability</h5>
                                        <p>We offer the most affordable rates in the online market. As a result, vendors
                                            of all sizes, backgrounds, and areas reach out to us for assistance. </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-2.png">
                                    <div class="why-txt">
                                        <h5>Hassle-Free</h5>
                                        <p>At Amazon Pro 360, we keep it hassle-free by introducing our seamless method
                                            to execute the job from beginning to end. </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-3.png">
                                    <div class="why-txt">
                                        <h5>Responsive Firm</h5>
                                        <p>You will not be left on your own wondering what is going on with your
                                            project. Our responsive players on the team keep you in the loop throughout
                                            the process. </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-4.png">
                                    <div class="why-txt">
                                        <h5>Project Managers</h5>
                                        <p>We assign project managers with remarkable managerial skills and experience
                                            to steer the projects taking care of each necessary detail. </p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="why-col-rgt">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-5.png">
                                    <div class="why-txt">
                                        <h5>Proficient Members</h5>
                                        <p>Amazon Pro 360 has handpicked the most exemplary members in the squad who
                                            deliver effective results. Here, we never go out of options to assign your
                                            project to a pro. </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-6.png">
                                    <div class="why-txt">
                                        <h5>Premium Work</h5>
                                        <p>We provide unique, custom e-commerce solutions from scratch to fulfill your
                                            requirements. You get nothing but brilliance in the form of premium work.
                                        </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-7.png">
                                    <div class="why-txt">
                                        <h5>Excellence Guarantee</h5>
                                        <p>Get recognition locally and internationally, target consumers, and
                                            personalize for a better buying experience and more with Amazon Pro 360.
                                        </p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-8.png">
                                    <div class="why-txt">
                                        <h5>Goal-Centric</h5>
                                        <p>We understand every customer comes to us with specific objectives in mind,
                                            and our mission is to employ our expertise to pursue those goals.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                        <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                            <h4><span>Consult Our Professionals</span><br> For Unbeatable Results</h4>
                            <p>We are just a few taps away from you!</p>
                        </div>
                        <div class="why-call-div-st">
                            <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                                <a href="tel:866-236-7122" class="callphone">
                                    <div class="why-img why-1">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                    <p>Call now</p>
                                    866-236-7122
                                </a>
                            </div>
                            <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                                <a href="javascript:;" onclick="setButtonURL();">
                                    <div class="why-img why-2">
                                        <img loading="lazy" src="images/message-img.png">
                                    </div>
                                    <p class="live-height">Live Chat</p>
                                </a>
                                <a href="tel:866-236-7122" class="callphone"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ecom-services">
        <div class="container">
            <div cass="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-duration="2s">Keep Your E-Commerce Store Booming with Our
                            E-Commerce Marketing Agency</h2>
                        <p class="wow fadeInUp" data-wow-duration="3s">Our e-commerce marketing makes it simple to
                            contact brand-loyal customers whenever you launch a new product or a sales campaign.</p>
                    </div>
                </div>
                <div class="col-sm-12 p0">
                    <div class="col-sm-4">
                        <div class="ecom-srv-box  wow fadeInLeft" data-wow-duration="3s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon1.png">
                            </div>
                            <h3>Amazon SEO Marketing </h3>
                            <p>To make your items more accessible to a wider audience, avail our Amazon SEO tactics to
                                enhance your product listings.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ecom-srv-box ecom-srv-box-3  wow fadeInLeft" data-wow-duration="2s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon2.png">
                            </div>
                            <h3>Amazon PPC Advertising </h3>
                            <p>Our PPC professionals create customized plans with the goal of increasing your ROI and
                                lowering your advertising expenditures.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ecom-srv-box  wow fadeInLeft" data-wow-duration="1s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon6.png">
                            </div>
                            <h3>Email Marketing with Amazon</h3>
                            <p>Email marketing allows you to promote your Amazon store items directly to customers who
                                are more likely to convert.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ecom-srv-box wow fadeInRight" data-wow-duration="1s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon3.png">
                            </div>
                            <h3>Video Marketing on Amazon</h3>
                            <p>Brands may attract customers with Amazon video marketing by creating targeted videos to
                                deliver the brand message.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ecom-srv-box ecom-srv-box-5 wow fadeInRight" data-wow-duration="2s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon5.png">
                            </div>
                            <h3>Social Media Marketing</h3>
                            <p>Our trained Amazon marketing advisors can help you connect with your target audience via
                                social media.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="ecom-srv-box wow fadeInRight" data-wow-duration="3s">
                            <div class="ecom-cir">
                                <img src="images/ecom-serv-icon1.png">
                            </div>
                            <h3>Research and Analysis</h3>
                            <p>Before creating any marketing plan, we do extensive brand research and competitive
                                analysis.</p>
                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="banner-btn btn-st  ecm-btn-st wow fadeInUp" data-wow-duration="2s">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-tab-new">
        <div class="container">
            <div class="hd-txt">
                <h2 class="wow fadeInUp" data-wow-duration="2s">Grow Sales Through Better Reach with E-Commerce
                    Marketing</h2>
                <p class="wow fadeInUp" data-wow-duration="3s">The right kind of e-commerce marketing from professionals
                    minimizes the day-to-day operation damages. </p>
            </div>
            <ul class="ecom-tabs">
                <li data-targetit="box-ecom-tab-1" class="active">Increase ROI</li>
                <li data-targetit="box-ecom-tab-2">Higher Reach</li>
                <li data-targetit="box-ecom-tab-3">Attract New Customers</li>
                <li data-targetit="box-ecom-tab-4">Customer Analytics</li>
                <li data-targetit="box-ecom-tab-5">Increased Accessibility</li>
            </ul>
            <div class="box-ecom-tab-1 showfirst">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ecom-tabhead-new">
                            <h5>Increase Roi</h5>
                            <p>Amazon marketing plays a significant role in increasing the ROI of your brand by
                                attracting more customers and compelling them to buy from your store.</p>
                        </div>
                        <div class="banner-btn btn-st  ">
                            <a href="javascript:;" class="get-started-header  " onclick="setButtonURL();">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ecom-tabs-images">
                            <img src="images/ecom-tab-img-1.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-ecom-tab-2">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ecom-tabhead-new">
                            <h5>Higher Reach</h5>
                            <p>Witness a spike in your store's reach. Amazon marketing makes online brand stores reach
                                more audiences than a traditional retail store.</p>
                        </div>
                        <div class="banner-btn btn-st  ">
                            <a href="javascript:;" class="get-started-header  " onclick="setButtonURL();">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ecom-tabs-images">
                            <img src="images/ecommerce-marketing-img-2.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-ecom-tab-3">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ecom-tabhead-new">
                            <h5>Attract New Customers</h5>
                            <p>While a physical store may only attract people passing by, Amazon stores attract a large
                                online audience. </p>
                        </div>
                        <div class="banner-btn btn-st  ">
                            <a href="javascript:;" class="get-started-header  " onclick="setButtonURL();">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ecom-tabs-images">
                            <img src="images/ecommerce-marketing-img-3.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-ecom-tab-4">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ecom-tabhead-new">
                            <h5>Customer Analytics</h5>
                            <p>Getting customer insights is a great way to improve the brand's performance—customer
                                analytics help refine your products and the whole marketing process.</p>
                        </div>
                        <div class="banner-btn btn-st  ">
                            <a href="javascript:;" class="get-started-header  " onclick="setButtonURL();">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ecom-tabs-images">
                            <img src="images/ecommerce-marketing-img-4.png">
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-ecom-tab-5">
                <div class="row">
                    <div class="col-md-6">
                        <div class="ecom-tabhead-new">
                            <h5>Increased Accessibility</h5>
                            <p>Ecommerce stores are more accessible as compared to physical retail stores. It saves the
                                clients' efforts, time, and money to travel to the store.</p>
                        </div>
                        <div class="banner-btn btn-st  ">
                            <a href="javascript:;" class="get-started-header  " onclick="setButtonURL();">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="ecom-tabs-images">
                            <img src="images/ecommerce-marketing-img-5.png">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="custom-cta">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="custom-cta-text">
                        <h2>Whether you are leading a brand-new or established e-commerce company, it is vital to
                            understand the value of e-commerce marketing and its benefits.</h2>

                    </div>
                </div>
                <div class="col-md-6 col-md-offset-1">
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img1.png">
                        <img src="images/custom-cta-img2.png">
                        <img src="images/custom-cta-img3.png">
                    </div>
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img4.png">
                        <img src="images/custom-cta-img5.png">
                        <img src="images/custom-cta-img6.png">
                    </div>
                    <div class="cta-main-btn wow fadeInUp" data-wow-duration="4s">
                        <a href="javascript:;" class="get-started get-started-cta ">Get A Quote</a>
                        <a href="tel:866-236-7122" class="call-st-cta callphone">Call US - 866-236-7122</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_consultancy-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">Target More Specific Leads with Our E-Commerce
                            Marketing</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Whether you are running a startup or an
                            established e-commerce business, it is important to understand the vitality of e-commerce
                            marketing in the contemporary era.</p>
                    </div>
                </div>
            </div>
            <div class="consultancy_slider">
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Run Successful Campaigtns</h3>
                        <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                            online stores, causing a drastic increase in sales and brand awareness.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Save Your Time</h3>
                        <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                            business in the long run as well. From creating optimized listings to plan advertising
                            campaigns, our team does it all for you.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img3.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Your Lack of Expertise</h3>
                        <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                            banned. When you hire Amazon professionals, they are well-aware of all the changing
                            policies.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_4">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Attract Potential Customers</h3>
                        <p>With a well-strategized product listing of the products, sell online to make money to get
                            hire sales of the products. Our Amazon experts have the expertise to portray your product in
                            a way that attracts potential customers.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Run Successful Campaigtns</h3>
                        <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                            online stores, causing a drastic increase in sales and brand awareness.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Save Your Time</h3>
                        <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                            business in the long run as well. From creating optimized listings to plan advertising
                            campaigns, our team does it all for you.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img3.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Your Lack of Expertise</h3>
                        <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                            banned. When you hire Amazon professionals, they are well-aware of all the changing
                            policies.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_4">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Attract Potential Customers</h3>
                        <p>With a well-strategized product listing of the products, sell online to make money to get
                            hire sales of the products. Our Amazon experts have the expertise to portray your product in
                            a way that attracts potential customers.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="multi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="multi-main-div">
                        <div class="multi-inner-div">
                            <ul class="multi-ul">
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                            <h4 class="wow fadeInUp" data-wow-duration="1s">We Offer Multi-Channel Solutions for
                                Businesses</h4>
                        </div>
                        <ul>
                            <li>
                                <div class="multi-logo-div wow fadeInUp" data-wow-duration="2s">
                                    <img src="images/multi-logo-1.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                            <li>
                                <div class="multi-logo-div wow fadeInUp" data-wow-duration="3s">
                                    <img src="images/multi-logo-2.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                            <li>
                                <div class="multi-logo-div wow fadeInUp" data-wow-duration="4s">
                                    <img src="images/multi-logo-3.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                            <li>
                                <div class="multi-logo-div wow fadeInUp" data-wow-duration="3s">
                                    <img src="images/multi-logo-4.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                            <li>
                                <div class="multi-logo-div wow fadeInUp" data-wow-duration="4s">
                                    <img src="images/multi-logo-5.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                            <li class="bdr-rem">
                                <div class="multi-logo-div bdr-rem wow fadeInUp" data-wow-duration="3s">
                                    <img src="images/multi-logo-6.png">
                                    <div class="star-img">
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                        <i class="fa fa-star" aria-hidden="true"></i>
                                    </div>
                                    <h5>100+ Reviews</h5>
                                </div>
                            </li>
                        </ul>
                        <p class="multi-p-txt wow fadeInUp" data-wow-duration="8s">“Amazon Pro 360 saved our time by
                            synchronizing our inventory on different channels that our store is operated at.”</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 ecom-cta-new">
                <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                    <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                        <h4><span>Do you have </span><br>any queries?</h4>
                        <p>Hit us up for any questions, and let us clear your confusion. </p>
                    </div>
                    <div class="why-call-div-st">
                        <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                            <a href="tel:866-236-7122" class="callphone">
                                <div class="why-img why-1">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <p>Call now</p>
                                866-236-7122
                            </a>
                        </div>
                        <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                            <a href="javascript:;" onclick="setButtonURL();">
                                <div class="why-img why-2">
                                    <img loading="lazy" src="images/message-img.png">
                                </div>
                                <p class="live-height">Live Chat</p>
                            </a>
                            <a href="tel:866-236-7122" class="callphone"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </section>
    <section class="testi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                        </h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                            reviews:</p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="testi-slider-st">
                        <div class="testi-slider">
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/testi-img2.png">
                                    <h3>Benjamin Stafford</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I hired them to manage my fashion store on Amazon and they did a
                                                great job with the managing as well as marketing. I am highly
                                                satisfied with their services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/testi-img1.png">
                                    <h3>Angie Roberts</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>They handled my Amazon store excellently and their team is highly
                                                responsive. They not only kept us updated about the progress, but
                                                also entertained all the buyer's queries really well. I recommend
                                                their Amazon marketing services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/testi-img3.png">
                                    <h3>Stanley Lucas</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I would give them a hundred stars if I could. Their services exceeded
                                                my expectations and the results I got from their services were
                                                exceptional. I am glad that I chose to work with such a professional
                                                agency.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php include './components/footer.php'; ?>