<?php include './components/header.php'; ?>
<section class="main-banner bubbles">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="mbnr-left-txt mbr-hd-ani">
                    <h1 class="wow fadeInUp" data-wow-duration="2s">LOOKING FOR THE BEST AMAZON <br>CONSULTANT IN
                        THE USA?</h1>
                    <h3 class="wow fadeInUp" data-wow-duration="2s">Hire Amazon Pro 360 to Enhance Your Sales</h3>
                    <p class="wow fadeInUp" data-wow-duration="3s">We have a team of professional Amazon consultants
                        at Amazon Pro 360 to help your brand skyrocket the revenues through robust Amazon store
                        setup and marketing strategies.</p>
                    <div class="banner-ul banner-ul-two">
                        <ul class="wow fadeInUp" data-wow-duration="3s">
                            <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle" aria-hidden="true"></i>Certified Amazon Consultants</li>
                            <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle" aria-hidden="true"></i>Increase in Revenues Guaranteed</li>
                            <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle" aria-hidden="true"></i>Enhance Your Brand Awareness</li>
                        </ul>
                    </div>
                    <div class="banner-btn btn-st wow fadeInUp" data-wow-duration="4s">
                        <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();" data-wow-duration="4s">Live Chat</a>
                        <a href="tel:866-236-7122" class="call-st wow fadeInUp callphone" data-wow-duration="4s">Call US - 866-236-7122</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-7">
                <div class="banner-side-img wow zoomIn" data-wow-duration="3s">
                    <img src="images/mbanner-side-img.png">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="selling-amazong bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="300ms">SET UP AN AMAZON STORE WITH THE BEST AMAZON
                        CONSULTING SERVICES</h2>
                    <p class="wow fadeInUp" data-wow-delay="350ms">Amazon Pro 360 extends the best amazon marketing
                        services in the USA. We serve vendors, retailers, and sellers from all backgrounds and
                        regions and help them with their e-commerce demands.</p>
                </div>
            </div>
            <div class="col-sm-12 sel-ama-col">
                <div class="col-sm-4">
                    <div class="sel-ama-box sel-ama-bx1 wow effect-bubba fadeInUp" data-wow-duration="1s">
                        <figcaption>
                        </figcaption>
                        <img loading="lazy" src="images/selling-img-1.png">
                        <div class="amazone_store_parrent">
                            <h3>Amazon Store Setup</h3>
                            <p>Set up a successful Amazon eCommerce store with us and sell your products easily
                                without facing any hassle.</p>
                            <div class="seling-btn-div">
                                <a href="javascript:;" class="sel-btn-st get-started">Get Free Consultation</a>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="sel-ama-box sel-ama-bx2 effect-bubba wow fadeInUp" data-wow-duration="2s">
                        <figcaption>
                        </figcaption>
                        <img loading="lazy" src="images/selling-img-2.png">
                        <div class="amazone_store_parrent">
                            <h3>Amazon Advertising</h3>
                            <p>To make sure that your online store reaches the right audience, we offer effective
                                Amazon Marketing solutions.</p>
                            <div class="seling-btn-div">
                                <a href="javascript:;" class="sel-btn-st get-started ">Get Free Consultation</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="sel-ama-box sel-ama-bx3 effect-bubba wow fadeInUp" data-wow-duration="3s">
                        <figcaption>
                        </figcaption>
                        <img loading="lazy" src="images/selling-img-3.png">
                        <div class="amazone_store_parrent">
                            <h3>Amazon Services</h3>
                            <p>Our FBA experts help your online store prosper. We offer comprehensive Amazon
                                services to facilitate brands.</p>
                            <div class="seling-btn-div">
                                <a href="javascript:;" class="sel-btn-st get-started">Get Free Consultation</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="why-choose bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="why-col-lft why-col-lft-heading">
                <h3 class="wow fadeInLeft" data-wow-delay="380ms">WHY CHOOSE</h3>
                <h2 class="wow fadeInLeft" data-wow-delay="400ms">Amazon Pro 360</h2>
                <p class="wow fadeInLeft" data-wow-delay="410ms">Amazon Pro 360 has been in the advertising industry
                    for over 20 years and has a team of Amazon experts to set up a unique store for brands. If you
                    are looking to sell online to make money, here are some reasons why you should work with us:</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6">
                <div class="why-col-lft">
                    <ul>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/why-icon-1.png">
                                <div class="why-txt">
                                    <h5>Amazon SEO</h5>
                                    <p>to improve the visibility of your products</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/why-icon-2.png">
                                <div class="why-txt">
                                    <h5>Store Management</h5>
                                    <p>for controlling your seller account</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/why-icon-3.png">
                                <div class="why-txt">
                                    <h5>Advertising</h5>
                                    <p>Yto improve sales by creating sponsored ads</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/why-icon-4.png">
                                <div class="why-txt">
                                    <h5>Boost Amazon Sales</h5>
                                    <p>by grabbing the attention of the audience.</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="why-col-rgt">
                    <ul>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/why-icon-5.png">
                                <div class="why-txt">
                                    <h5>Optimized Content</h5>
                                    <p>To improve your product’s ranking on search results</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/why-icon-6.png">
                                <div class="why-txt">
                                    <h5>Responsive with buyers</h5>
                                    <p>to provide excellent customer support</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/why-icon-7.png">
                                <div class="why-txt">
                                    <h5>Price & Product Comparison</h5>
                                    <p>to help your business have a competitive edge</p>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/why-icon-8.png">
                                <div class="why-txt">
                                    <h5>Various Payment Methods</h5>
                                    <p>to ensure 100% customer satisfaction</p>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                    <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                        <h4><span>Learn More About</span><br> Our Services</h4>
                        <p>Get in touch with our online consultant.</p>
                    </div>
                    <div class="why-call-div-st">
                        <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                            <a href="tel:866-236-7122" class="callphone">
                                <div class="why-img why-1">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <p>Call now</p>
                                866-236-7122
                            </a>
                        </div>
                        <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                            <a href="javascript:;" onclick="setButtonURL();">
                                <div class="why-img why-2">
                                    <img loading="lazy" src="images/message-img.png">
                                </div>
                                <p class="live-height">Live Chat</p>
                            </a>
                            <a href="tel:866-236-7122" class="callphone"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="amazon_consultancy-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">REASONS WHY YOU NEED TO HIRE AN AMAZON
                        CONSULTANT AGENCY</h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">If you are skeptical about hiring an Amazon
                        business consultant to promote your online store, here are some of the great reasons to hire
                        the professionals of Amazon Pro 360 for this job:</p>
                </div>
            </div>
        </div>
        <div class="consultancy_slider">
            <div class="consultancy_slid consultancy_slid_1">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img1.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Run Successful Campaigns</h3>
                    <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                        online stores, causing a drastic increase in sales and brand awareness.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_2">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img2.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Save Your Time</h3>
                    <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                        business in the long run as well. From creating optimized listings to plan advertising
                        campaigns, our team does it all for you.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_3">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img3.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Your Lack of Expertise</h3>
                    <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                        banned. When you hire Amazon professionals, they are well-aware of all the changing
                        policies.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_4">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img4.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Attract Potential Customers</h3>
                    <p>With a well-strategized product listing of the products, sell online to make money to get
                        hire sales of the products. Our Amazon experts have the expertise to portray your product in
                        a way that attracts potential customers.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_1">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img1.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Run Successful Campaigtns</h3>
                    <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                        online stores, causing a drastic increase in sales and brand awareness.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_2">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img2.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Save Your Time</h3>
                    <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                        business in the long run as well. From creating optimized listings to plan advertising
                        campaigns, our team does it all for you.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_3">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img3.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Your Lack of Expertise</h3>
                    <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                        banned. When you hire Amazon professionals, they are well-aware of all the changing
                        policies.</p>
                </div>
            </div>
            <div class="consultancy_slid consultancy_slid_4">
                <div class="consultancy_slider_img">
                    <img src="images/consultancy-slide-img4.png">
                </div>
                <div class="consultancy_slid_box">
                    <h3>Attract Potential Customers</h3>
                    <p>With a well-strategized product listing of the products, sell online to make money to get
                        hire sales of the products. Our Amazon experts have the expertise to portray your product in
                        a way that attracts potential customers.</p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="amazon_market_sec">
    <div class="">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">PLATFORMS WE ARE ASSOCIATED WITH</h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Amazon Pro 360 has an alliance with numerous
                        online platforms. Here are a few of many renowned brands we have set up Amazon shops for:
                    </p>
                </div>
            </div>
        </div>
        <div class="amazon_market_slider">
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img1.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img2.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img3.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img4.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img5.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img6.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img7.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img8.jpg"></div>
        </div>
    </div>
</section>
<section class="faq-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">Frequently Asked Question </h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Do you have queries in mind?</p>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="accordion wow fadeIn" data-wow-duration="3s" id="accordion2">
                    <div class="wrapper center-block">
                        <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                            <div class="panel panel-default">
                                <div class="panel-heading active" role="tab" id="headingOne">
                                    <h4 class="panel-title">
                                        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What are the best ways to sell products on Amazon?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
                                    <div class="panel-body">
                                        <p>There are numerous ways to market your products on Amazon like listing
                                            optimization, concise product descriptions, professional product images,
                                            fulfilment by Amazon, Sponsored ads, and many other ways to improve your
                                            online Amazon store.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingTwo">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            Why do I need to hire Amazon Marketing professionals?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
                                    <div class="panel-body">
                                        <p>Hiring Amazon marketing professionals help in increasing the visibility
                                            of your online store and brings in more traffic leading to increased
                                            sales. Amazon Marketing professionals have extensive knowledge about the
                                            latest Amazon policies; hence, they market your products the right way
                                            ensuring that your store meets all the Amazon guidelines.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingThree">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            My eCommerce store is already successful, why do I need to Hire Amazon
                                            Marketing professionals?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
                                    <div class="panel-body">
                                        <p>It’s good that your eCommerce store is doing good, but there is no harm
                                            in giving Amazon Marketing professionals a chance to leverage your
                                            successful business to a higher level of success. Hiring a marketing
                                            agency can boost your sales and increase your brand awareness.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingFour">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                                            My products are getting a great response on Amazon but the Amazon
                                            charges are eating up most of my profit. How can I boost my business
                                            sales?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseFour" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFour">
                                    <div class="panel-body">
                                        <p>When you feel that your strategy is not able to generate enough money,
                                            it’s time to revise the marketing strategy. Amazon Pro 360 creates a
                                            custom strategy by marketing the products in different marketplaces.
                                            This way, we are able to boost sales and improve brand awareness.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingFive">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                                            When is the right time to hire an Amazon Marketing Agency?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseFive" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingFive">
                                    <div class="panel-body">
                                        <p>The earlier you hire Amazon marketing professionals, the better it is for
                                            your business. But it’s never too late to hire professionals to improve
                                            your business’s growth and sales as professionals use modernized
                                            strategies to market products. For those business owners who want to
                                            free up their time, hiring a marketing agency is the best bet.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="panel panel-default">
                                <div class="panel-heading" role="tab" id="headingSix">
                                    <h4 class="panel-title">
                                        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseSix" aria-expanded="false" aria-controls="collapseSix">
                                            How long does it take to set up an online eCommerce store?
                                        </a>
                                    </h4>
                                </div>
                                <div id="collapseSix" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingSix">
                                    <div class="panel-body">
                                        <p>It takes 3-4 weeks to set up an online eCommerce store, but this duration
                                            can vary based on your specifications. We have a highly expert team who
                                            can get this job done for you within a fast turnaround time taking care
                                            of the quality of work. </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="cat_2mm">
    <div class="container">
        <div class="col-sm-12">
            <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                    <h4><span>Do you have any confusion about </span>placing an order<span>?</span></h4>
                    <p>Our professionals are just a call away to respond to your queries. Call us or chat live to
                        get your answers.</p>
                </div>
                <div class="why-call-div-st">
                    <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                        <a href="tel:866-236-7122" class="callphone">
                            <div class="why-img why-1">
                                <i class="fa fa-phone" aria-hidden="true"></i>
                            </div>
                            <p>Call now</p>
                            866-236-7122
                        </a>
                    </div>
                    <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                        <a href="javascript:;" onclick="setButtonURL();">
                            <div class="why-img why-2">
                                <img loading="lazy" src="images/message-img.png">
                            </div>
                            <p class="live-height">Live Chat</p>
                        </a>
                        <a href="tel:866-236-7122" class="callphone"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                        </h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                            reviews:</p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="testi-slider-st">
                        <div class="testi-slider">
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/testi-img2.png">
                                    <h3>Benjamin Stafford</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I hired them to manage my fashion store on Amazon and they did a
                                                great job with the managing as well as marketing. I am highly
                                                satisfied with their services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/testi-img1.png">
                                    <h3>Angie Roberts</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>They handled my Amazon store excellently and their team is highly
                                                responsive. They not only kept us updated about the progress, but
                                                also entertained all the buyer's queries really well. I recommend
                                                their Amazon marketing services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/testi-img3.png">
                                    <h3>Stanley Lucas</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I would give them a hundred stars if I could. Their services exceeded
                                                my expectations and the results I got from their services were
                                                exceptional. I am glad that I chose to work with such a professional
                                                agency.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>
<?php include './components/footer.php'; ?>