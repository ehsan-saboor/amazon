<footer class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-4">
                <div class="ftr-col ftr-1">
                    <img loading="lazy" src="images/logo-ftr.png">
                    <p>Amazon Pro 360 is a renowned Amazon Consultation company in the USA known for providing
                        robust Amazon eCommerce solutions to skyrocket the revenues for brands.</p>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ftr-col ftr-2">
                    <h3>Services</h3>
                    <ul>
                        <li><a href="ecommerce-store-setup.php">Ecommerce Store Setup</a></li>
                        <li><a href="ecommerce-marketing.php">Ecommerce Marketing</a></li>
                        <li><a href="amazon-services.php">Amazon Services</a></li>
                        <li><a href="about-us.php">About</a></li>
                        <li><a href="teams.php">Teams</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-2">
                <div class="ftr-col ftr-2">
                    <h3>Platform</h3>
                    <ul>
                        <li><a href="contact-us.php">Contact Us</a></li>
                        <li><a href="testimonials.php">Testimonials</a></li>
                        <li><a href="terms.php" class="ftr-li">Terms Conditions</a></li>
                        <li><a href="privacy.php" class="ftr-li">Privacy Policy</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-3">
                <div class="ftr-col ftr-2">
                    <h3>Address</h3>
                    <ul>
                        <li><a href="tel:866-236-7122" class="ftr-li callphone">866-236-7122</a></li>
                        <li><a href="mailto:sales@amazonpro360.com" class="ftr-li">sales@amazonpro360.com</span></a>
                        </li>

                        <li><a href="javascript:;" onclick="setButtonURL();" class="ftr-li">Live Chat </a></li>
                        <li><a href="javascript:;" class="ftr-li popup-btn">Get a Quote </a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="copyright-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p>All Rights Reserved 2022 - Amazon Pro 360</p>
                </div>
                <div class="col-md-6">
                    <ul class="trust-box">
                        <li class="pl-0">
                            <a target="blank" href="https://www.facebook.com/Amazon-Pro-360-102910169052636">
                                <i class="fa fa-facebook-f"></i>
                            </a>&nbsp;&nbsp;
                            <a target="blank" href="https://www.instagram.com/amazonpro360/">
                                <i class="fa fa-instagram" aria-hidden="true"></i>
                            </a> &nbsp;&nbsp;

                            <a target="blank" href="https://www.linkedin.com/company/amazon-pro-360">
                                <i class="fa fa-linkedin-square" aria-hidden="true"></i>
                            </a>
                            <a target="blank" href="javascript:;">
                                <img src="images/trustpilot-iconcopy33.png">
                            </a>
                            <a target="blank" href="javascript:;">
                                <img src="images/bark-icon.png">
                            </a>
                            <a target="blank" href="javascript:;">
                                <img src="images/review-icon-2.png">
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<div style="display: none;" class="popupform" id="popupform">
    <h2>We are here to help!</h2>
    <p>Providing you the perfect solutions for your business needs. Let's work together and unlock doors to success.
    </p>
    <form action="#!" method="post" class="validate-popupform">
        <div class="row">
            <div class="col-md-12">
                <ul>
                    <li> <i class="fa fa-user" aria-hidden="true"></i>
                        <input type="text" class="required" required="" placeholder="Full Name *" name="cn">
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <ul>
                    <li> <i class="fa fa-envelope-o" aria-hidden="true"></i>
                        <input type="email" class="required email" required="" placeholder="Email Address *" name="em">
                    </li>
                </ul>
            </div>
            <div class="col-md-6">
                <ul>
                    <li> <i class="fa fa-phone" aria-hidden="true"></i>
                        <input type="text" class="required number" minlength="10" required="" placeholder="Phone No. *" name="pn" required="">
                    </li>
                </ul>
            </div>
            <div class="col-md-12">
                <ul>
                    <li> <i class="fa fa-paper-plane-o" aria-hidden="true"></i>
                        <textarea name="msg" class="required" required="" placeholder="To help us understand better, enter a brief description about your project."></textarea>
                    </li>
                </ul>
            </div>
            <div class="col-md-12">
                <ul>
                    <li>
                        <input type="submit" value="Submit">
                        
                    </li>
                </ul>
            </div>
        </div>
    </form>
</div>

<div class="popupform-main">
    <div class="pop-form ta-center">
        <div class="col-sm-6">
            <div class="popup-l-side pop-amz-new-side-1">
                <img src="images/pop-new-logo-amz.png">
                <h3>Professional</h3>
                <h2>E-Commerce <span>and</span> Amazon Services</h2>
            </div>
        </div>
        <div id="pop-form" class="col-sm-6">
            <div class="pop-form-amz-new">
                <h3>Boost Your Online Presence </h3>
                <h2>And Avail <strong>50% Discount</strong> on Signup </h2>

                <a href="javascript:;" class="close-btn ta-center">X</a>
                <div class="clearfix"></div>
                <form action="#!" class="jform validate main-pop" method="POST">
                    <div class="col-md-12">
                        <div class="control-group">
                            <input type="text" placeholder="Name" name="cn" class="required" required="" onkeypress="return /[a-z]/i.test(event.key)">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="control-group">
                            <input type="email" name="em" class="required email" placeholder="Enter your email here" required="">
                        </div>
                    </div>
                    <div class="col-md-12 phonecode">
                        <div class="control-group clearfix">
                            <div class="numberarea">
                                <input type="number" name="pn" id="phone" class="number required" placeholder="Phone Number" required="" onkeypress="return /[0-9]/i.test(event.key)">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 ">
                        <div class="control-group clearfix">
                            <div class="textarea_auto">
                                <textarea class="form-control" name="msg" placeholder="Talk about your project" required=""></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="control-group clearfix  ">
                            <input type="submit" class="btn btn-default pop_btn submit-btn fspx-23  ls-medium d-block w-100 fw-bold" value="Submit">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="js/jquery-1.10.2.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/fancybox.js"></script>
<script src="js/slick.js"></script>
<script src="js/accordian-jquery-ui.js"></script>
<script src="js/modernizr_2.6.3-custom.js"></script>
<script src="js/owl.carousel.min.js"></script>
<script src="js/wow.min.js"></script>
<script src="js/chat.js"></script>
<script src="js/custom.js"></script>
<!-- <script>
    // Add event listener to table
    var el = document.getElementsByClassName("callphone");
    //    el.addEventListener("click", gtag_report_conversion, false);


    for (var i = 0; i < el.length; i++) {
        el[i].addEventListener('click', gtag_report_conversion, false);
    }

    function gtag_report_conversion(url) {
        //      alert('Testing');
        var callback = function() {
            if (typeof(url) != 'undefined') {
                //        window.location = url;
            }
        };
        gtag('event', 'conversion', {
            'send_to': 'AW-796519964/vVsFCN618e8CEJzc5_sC',
            'event_callback': callback
        });
        return false;
    }
</script> -->
<script>
    // $(document).ready(function() {
    //     //var currentIP;
    //     var key = '5XpThOAEkfgOvEJ';
    //     var currentIP = $("meta[name=ip2loc]").attr('content');
    //     var pgurl = $("meta[name=page_url]").attr('content');
    //     $.ajax({
    //         method: 'get',
    //         url: '//pro.ip-api.com/json/' + currentIP,
    //         data: {
    //             key: key
    //         },
    //         success: function(data) {
    //             if (data) {
    //                 $('input[name=ip2loc_ip]').val(data.query);
    //                 $('input[name=ip2loc_isp]').val(data.isp);
    //                 $('input[name=ip2loc_org]').val(data.org);
    //                 $('input[name=ip2loc_country]').val(data.country);
    //                 $('input[name=ip2loc_region]').val(data.regionName);
    //                 $('input[name=ip2loc_city]').val(data.city);
    //                 $('input[name=pageurl]').val(pgurl);



    //             }
    //         }
    //     });
    // });
    $('.popup-btn, .get-started').on('click', function() {
        $('.popupform-main').addClass('active');
        $('body').addClass('o-hidden');
        $('.overlay-bg').fadeIn(500);
        $('.close-btn').on('click', function() {
            $('.popupform-main').removeClass('active');
            $('body').removeClass('o-hidden');
            $('.overlay-bg').fadeOut(500);
        });
        $('.overlay-bg').click(function() {
            $('popupform-main').removeClass('active');
            $('body').removeClass('o-hidden');
            $('.overlay-bg').fadeOut(500);

        });
    });
    // Created for an Articles on:
    // https://www.html5andbeyond.com/bubbling-text-effect-no-canvas-required/
    jQuery(document).ready(function($) {

        // Define a blank array for the effect positions. This will be populated based on width of the title.
        var bArray = [];
        // Define a size array, this will be used to vary bubble sizes
        var sArray = [4, 6, 8, 10];

        // Push the header width values to bArray
        for (var i = 0; i < $('.bubbles').width(); i++) {
            bArray.push(i);
        }

        // Function to select random array element
        // Used within the setInterval a few times
        function randomValue(arr) {
            return arr[Math.floor(Math.random() * arr.length)];
        }

        // setInterval function used to create new bubble every 350 milliseconds
        setInterval(function() {

            // Get a random size, defined as variable so it can be used for both width and height
            var size = randomValue(sArray);
            // New bubble appeneded to div with it's size and left position being set inline
            // Left value is set through getting a random value from bArray
            $('.bubbles').append('<div class="individual-bubble" style="left: ' + randomValue(bArray) + 'px; width: ' + size + 'px; height:' + size + 'px;"></div>');

            // Animate each bubble to the top (bottom 100%) and reduce opacity as it moves
            // Callback function used to remove finsihed animations from the page
            $('.individual-bubble').animate({
                'bottom': '100%',
                'opacity': '-=0.7'
            }, 3000, function() {
                $(this).remove()
            });


        }, 350);

    });
    // $(".seling-btn-div").mouseover(function(){
    //   $(".sel-btn-hvr").css("left", "30px");
    // });
    // $(".seling-btn-div").mouseout(function(){
    //   $(".sel-btn-hvr").css("left", "-300px");
    // });
</script>

</body>

</html>