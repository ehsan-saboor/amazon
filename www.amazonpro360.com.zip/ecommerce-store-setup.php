<?php include './components/header.php'; ?>
<section class="serv-banner services-bnr ecom-stor-bnr">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="mbnr-left-txt">
                        <h1 class="wow fadeInUp" data-wow-duration="2s">START SELLING ONLINE WITH OUR AMAZON STORE SETUP
                            SERVICES</h1>
                        <p class="wow fadeInUp" data-wow-duration="3s">Sell Online Make Money helps businesses build a
                            robust presence on Amazon, the world's largest eCommerce platform. Our Amazon experts have a
                            deep understanding of the industry and manage day-to-day tasks for brands to ensure seamless
                            operations.</p>
                        <div class="banner-ul">
                            <ul class="wow fadeInUp" data-wow-duration="2s">
                                <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Amazon FBA Setup and Management</li>
                                <li class="wow fadeInUp" data-wow-duration="4s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Storefront Customization</li>
                                <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>24/7 Store Setup Assistance</li>
                                <li class="wow fadeInUp" data-wow-duration="4s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Store Management</li>
                                <li class="wow fadeInUp" data-wow-duration="3s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Optimized Product Listing</li>
                                <li class="wow fadeInUp" data-wow-duration="4s"><i class="fa fa-check-circle"
                                        aria-hidden="true"></i>Amazon Analytics</li>
                            </ul>


                        </div>
                        <div class="banner-btn btn-st wow fadeInUp" data-wow-duration="4s">
                            <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();"
                                data-wow-duration="4s">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="banner-side-img wow zoomIn" data-wow-duration="3s">
                        <img src="images/ecom-store-bnr-side-img.png">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-sec-two">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-5">
                        <div class="services-pro-img">
                            <img class="wow zoomIn" data-wow-duration="2s" src="images/ecom-store-inner-img-new.png"
                                style="visibility: visible; animation-duration: 2s; animation-name: zoomIn;">

                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="about-who-txt">
                            <h2 class="wow fadeInLeft" data-wow-duration="2s"
                                style="visibility: visible; animation-duration: 2s; animation-name: fadeInLeft;">#1
                                E-Commerce Store Setup Online</h2>
                            <p class="wow fadeInLeft" data-wow-duration="3s"
                                style="visibility: visible; animation-duration: 3s; animation-name: fadeInLeft;">Amazon
                                Pro 360 is a leading e-commerce online store company where we allow retailers of all
                                sizes, types, and regions to avail e-commerce store development. With hundreds of
                                additional add-ons, it helps businesses establish new sites, expand into new
                                geographies, improve sales, and develop their business faster.</p>
                        </div>
                        <div class="services-about-ul">
                            <ul>
                                <li class="wow fadeInLeft" data-wow-duration="2s"
                                    style="visibility: visible; animation-duration: 2s; animation-name: fadeInLeft;"><i
                                        class="fa fa-check-circle" aria-hidden="true"></i>Lower set up and running costs
                                </li>
                                <li class="wow fadeInLeft" data-wow-duration="3s"
                                    style="visibility: visible; animation-duration: 3s; animation-name: fadeInLeft;"><i
                                        class="fa fa-check-circle" aria-hidden="true"></i>Yield higher margins ecommerce
                                    race</li>
                                <li class="wow fadeInLeft" data-wow-duration="4s"
                                    style="visibility: visible; animation-duration: 4s; animation-name: fadeInLeft;"><i
                                        class="fa fa-check-circle" aria-hidden="true"></i>Availability of user-friendly
                                    features</li>
                                <li class="wow fadeInLeft" data-wow-duration="2s"
                                    style="visibility: visible; animation-duration: 2s; animation-name: fadeInLeft;"><i
                                        class="fa fa-check-circle" aria-hidden="true"></i>Efficiently manage the store
                                    inventory</li>
                            </ul>

                        </div>
                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInLeft" data-wow-duration="2s"
                            style="visibility: visible; animation-duration: 2s; animation-name: fadeInLeft;">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st  w callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_market_sec">
        <div class="">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">PLATFORMS WE ARE ASSOCIATED WITH</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Amazon Pro 360 has an alliance with numerous
                            online platforms. Here are a few of many renowned brands we have set up Amazon shops for:
                        </p>
                    </div>
                </div>
            </div>
            <div class="amazon_market_slider">
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img1.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img2.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img3.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img4.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img5.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img6.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img7.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img8.jpg"></div>
            </div>
        </div>
    </section>
    <section class="why-choose bdr-btm-sec">
        <div class="container">
            <div class="row">
                <div class="why-col-lft why-col-lft-heading">
                    <h3 class="wow fadeInLeft" data-wow-delay="380ms">WHY CHOOSE</h3>
                    <h2 class="wow fadeInLeft" data-wow-delay="400ms">Amazon Pro 360</h2>
                    <p class="wow fadeInLeft" data-wow-delay="410ms">Amazon Pro 360 has been in the advertising industry
                        for over 20 years and has a team of Amazon experts to set up a unique store for brands. If you
                        are looking to sell online to make money, here are some reasons why you should work with us:</p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="why-col-lft">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-1.png">
                                    <div class="why-txt">
                                        <h5>Amazon SEO</h5>
                                        <p>to improve the visibility of your products</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-2.png">
                                    <div class="why-txt">
                                        <h5>Store Management</h5>
                                        <p>for controlling your seller account</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-3.png">
                                    <div class="why-txt">
                                        <h5>Advertising</h5>
                                        <p>Yto improve sales by creating sponsored ads</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-4.png">
                                    <div class="why-txt">
                                        <h5>Boost Amazon Sales</h5>
                                        <p>by grabbing the attention of the audience.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="why-col-rgt">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-5.png">
                                    <div class="why-txt">
                                        <h5>Optimized Content</h5>
                                        <p>To improve your product’s ranking on search results</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-6.png">
                                    <div class="why-txt">
                                        <h5>Responsive with buyers</h5>
                                        <p>to provide excellent customer support</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-7.png">
                                    <div class="why-txt">
                                        <h5>Price & Product Comparison</h5>
                                        <p>to help your business have a competitive edge</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-8.png">
                                    <div class="why-txt">
                                        <h5>Various Payment Methods</h5>
                                        <p>to ensure 100% customer satisfaction</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                        <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                            <h4><span>Learn More About</span><br> Our Services</h4>
                            <p>Get in touch with our online consultant.</p>
                        </div>
                        <div class="why-call-div-st">
                            <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                                <a href="tel:866-236-7122" class="callphone">
                                    <div class="why-img why-1">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                    <p>Call now</p>
                                    866-236-7122
                                </a>
                            </div>
                            <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                                <a href="javascript:;" onclick="setButtonURL();">
                                    <div class="why-img why-2">
                                        <img loading="lazy" src="images/message-img.png">
                                    </div>
                                    <p class="live-height">Live Chat</p>
                                </a>
                                <a href="tel:866-236-7122" class="callphone"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_consultancy-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">REASONS WHY YOU NEED TO HIRE AN AMAZON
                            CONSULTANT AGENCY</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">If you are skeptical about hiring an Amazon
                            business consultant to promote your online store, here are some of the great reasons to hire
                            the professionals of Amazon Pro 360 for this job:</p>
                    </div>
                </div>
            </div>
            <div class="consultancy_slider">
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Run Successful Campaigns</h3>
                        <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                            online stores, causing a drastic increase in sales and brand awareness.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Save Your Time</h3>
                        <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                            business in the long run as well. From creating optimized listings to plan advertising
                            campaigns, our team does it all for you.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img3.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Your Lack of Expertise</h3>
                        <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                            banned. When you hire Amazon professionals, they are well-aware of all the changing
                            policies.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_4">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Attract Potential Customers</h3>
                        <p>With a well-strategized product listing of the products, sell online to make money to get
                            hire sales of the products. Our Amazon experts have the expertise to portray your product in
                            a way that attracts potential customers.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Run Successful Campaigtns</h3>
                        <p>Our Amazon seller consultants are skilled at planning and running successful campaigns for
                            online stores, causing a drastic increase in sales and brand awareness.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Save Your Time</h3>
                        <p>Hiring Amazon professionals to set up your online store saves your time. It benefits your
                            business in the long run as well. From creating optimized listings to plan advertising
                            campaigns, our team does it all for you.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img3.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Your Lack of Expertise</h3>
                        <p>While Amazon is a rewarding platform for sellers, some policies can get your online store
                            banned. When you hire Amazon professionals, they are well-aware of all the changing
                            policies.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_4">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Attract Potential Customers</h3>
                        <p>With a well-strategized product listing of the products, sell online to make money to get
                            hire sales of the products. Our Amazon experts have the expertise to portray your product in
                            a way that attracts potential customers.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-sec-new">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mag-ul-div">
                        <ul>
                            <li class=" wow fadeInUp" data-wow-duration="2s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-1-icon.png">
                                    <p>It helps in overseeing the inventory & ensures customer satisfaction</p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp" data-wow-duration="3s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-2-icon.png">
                                    <p>It allows you to track the progress of each order</p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp" data-wow-duration="4s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-3-icon.png">
                                    <p>It improves the efficiency and the security of orders</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="cat_2mm">
        <div class="container">
            <div class="col-sm-12">
                <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                    <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                        <h4><span>Do you have </span>any queries<span>?</span></h4>
                        <p>Hit us up for any questions, and let us clear your confusion. </p>
                    </div>
                    <div class="why-call-div-st">
                        <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                            <a href="tel:866-236-7122" class="callphone">
                                <div class="why-img why-1">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <p>Call now</p>
                                866-236-7122
                            </a>
                        </div>
                        <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                            <a href="javascript:;" onclick="setButtonURL();">
                                <div class="why-img why-2">
                                    <img loading="lazy" src="images/message-img.png">
                                </div>
                                <p class="live-height">Live Chat</p>
                            </a>
                            <a href="tel:866-236-7122" class="callphone"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="testi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                        </h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                            reviews:</p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="testi-slider-st">
                        <div class="testi-slider">
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/testi-img2.png">
                                    <h3>Benjamin Stafford</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I hired them to manage my fashion store on Amazon and they did a
                                                great job with the managing as well as marketing. I am highly
                                                satisfied with their services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/testi-img1.png">
                                    <h3>Angie Roberts</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>They handled my Amazon store excellently and their team is highly
                                                responsive. They not only kept us updated about the progress, but
                                                also entertained all the buyer's queries really well. I recommend
                                                their Amazon marketing services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/testi-img3.png">
                                    <h3>Stanley Lucas</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I would give them a hundred stars if I could. Their services exceeded
                                                my expectations and the results I got from their services were
                                                exceptional. I am glad that I chose to work with such a professional
                                                agency.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php include './components/footer.php'; ?>