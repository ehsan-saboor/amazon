<?php include './components/header.php'; ?>
<section class="serv-banner about-bnr terms-bnr">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="mbnr-left-txt">
                    <h1 class="wow fadeInUp" data-wow-duration="2s">Term & Coniditions</h1>

                    <div class="banner-btn btn-st  wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
            <div class="col-sm-7">

            </div>
        </div>
    </div>
</section>
<section class="terms-txt-st">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="trm-txt">
                    <p>
                        Welcome to Amazon Pro 360 corporate web site (the “Site”). This Site is owned by Amazon Pro
                        360. Our company information is as follows:<br><br>
                        The purpose of this section is to describe the conditions (the “Terms”) that apply to your
                        access to and use of our Site. If you visit us on this Site, we will assume that you
                        understand and intend these Terms to apply to you and your visit. The following points may
                        help you to understand the legal environment in which we operate:
                    </p>
                    <h3>Rights</h3>
                    <p>All of the material you see on this site is owned by us or used by us with the consent of the
                        owner. We are very happy for you to visit this Site and to print copies of material on it
                        for your personal, non-commercial use, but all other copying is prohibited and all other
                        rights are reserved.</p>
                    <h3>No Warranties </h3>
                    <p>
                        We provide this Site “as is”. We have taken care in preparing materials for the Site but we
                        cannot guarantee that:<br>
                        Material or software downloaded from the Site will be compatible with your equipment or free
                        from viruses;<br>
                        All materials will be accurate or complete.
                    </p>
                    <h3>Our Liability </h3>
                    <p>
                        To the fullest extent possible at law we exclude all liability for any loss or damage
                        (including direct, indirect, economic or consequential loss or damage) suffered by you as a
                        result of any visit to or use of this site or of any materials provided on it or downloaded
                        from it or your inability to use this site or any error in the provision of this Site or any
                        computer virus transmitted through this Site whether such loss or damage arises from our
                        negligence or otherwise and even if we are expressly informed of the possibility of such
                        loss or damage.
                    </p>
                    <h3>Refund Policy</h3>
                    <p>Sell Money Make Online offers a no-hassle refund policy to its customers. Certain conditions
                        apply.<br><br>
                        If you wish to cancel your order and discontinue our services before the project has begun,
                        you may do so and Sell Money Make Online will provide you with a complete 100% refund minus
                        the transaction charges.<br><br>
                        If you wish to discontinue our services while the project is still active, Sell Money Make
                        Online will refund you the balance payment of your order. The amount for which we have
                        already done the work for your project will be retained and the remaining balance will be
                        refunded. Note that no refund will be made on “change of mind” after the project work has
                        begun.<br><br>
                        Any type of project—whether active, on hold, in-progress or already completed—will be
                        ineligible for a partial or full refund provided that payment for that project was made 90
                        days ago or more than 90 days ago. <br><br>
                        If you have any specific concerns and require a complete refund, you may send us a refund
                        request and we will take the decision accordingly.</p>
                    <h3>Links to other sites </h3>
                    <p>
                        Links to third party sites on this web site are provided solely for users’ convenience. If
                        you use these links, you leave this Site. We have not reviewed all of these third-party
                        websites and do not control and are not responsible for these websites or their content. We
                        therefore do not endorse or make any representations about them or any material found there,
                        or any results that may be obtained from using them. If you decide to access any of the
                        third-party websites linked to this Site, you do so entirely at your own risk.
                    </p>
                    <h3>Links to this site </h3>
                    <p>If you would like to link to this website, you may only do so on the basis that you link to,
                        but do not replicate, the home page of this Website, and subject to the following
                        conditions:</p>
                    <ul>
                        <li>you do not remove, distort or otherwise alter the size or appearance of our images;</li>
                        <li>you do not create a frame or any other browser or border environment around this Site;
                        </li>
                        <li>you do not in any way imply that we are endorsing any products or services other than
                            our own;</li>
                        <li>you do not misrepresent your relationship with us nor present any other false
                            information about us;</li>
                        <li>you do not otherwise use any trade marks displayed on this Site without written
                            permission from us;</li>
                        <li>you do not link from a website that is not owned by you; and your website does not
                            contain content that is distasteful, offensive or controversial, infringes any
                            intellectual property rights or other rights of any other person or otherwise does not
                            comply with all applicable laws and regulations.</li>
                        <li>Other legal notices – there may be other legal notices on areas of this Site that relate
                            to your use of specific areas.</li>
                        <li>Changes to this legal notice – we may amend this legal notice from time to time.</li>
                    </ul>
                    <h3>Privacy Policy </h3>
                    <p>
                        It is important that you understand the way in which we will use the information we hold
                        about you. Please visit our Privacy Policy page for more information on user privacy and
                        security and how Amazon Pro 360 uses the information provided by users.<br><br>
                        If you have any questions or for media queries please send us an email to <a href="mailto:sales@amazonpro360.com"><b><span class="__cf_email__" >sales@amazonpro360.com</span></b></a>
                        and our marketing manager shall respond to you with appropriate answers.
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testi-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                    </h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                        reviews:</p>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="testi-slider-st">
                    <div class="testi-slider">
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/testi-img2.png">
                                <h3>Benjamin Stafford</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I hired them to manage my fashion store on Amazon and they did a
                                            great job with the managing as well as marketing. I am highly
                                            satisfied with their services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/testi-img1.png">
                                <h3>Angie Roberts</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>They handled my Amazon store excellently and their team is highly
                                            responsive. They not only kept us updated about the progress, but
                                            also entertained all the buyer's queries really well. I recommend
                                            their Amazon marketing services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/testi-img3.png">
                                <h3>Stanley Lucas</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I would give them a hundred stars if I could. Their services exceeded
                                            my expectations and the results I got from their services were
                                            exceptional. I am glad that I chose to work with such a professional
                                            agency.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>a
<?php include './components/footer.php'; ?>