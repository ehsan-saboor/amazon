<?php include './components/header.php'; ?>

<section class="serv-banner about-bnr services-bnr">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="mbnr-left-txt">
                    <h1 class="wow fadeInUp" data-wow-duration="2s">CHOOSE THE EXPERTS IN E-COMMERCE AND AMAZON</h1>
                    <p class="wow fadeInUp" data-wow-duration="3s">We offer exclusive marketing, Amazon, and
                        eCommerce store setup services to online sellers worldwide. We have professional and
                        experienced team members who significantly understand e-commerce and how the Amazon Platform
                        works.</p>
                    <div class="banner-btn btn-st  wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();" data-wow-duration="4s">Live Chat</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Contact us - 866-236-7122</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-7">
                <div class="about-img">
                    <img src="images/about-people.png">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-who-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-6">
                <div class="about-who-img wow zoomIn" data-wow-duration="2s">
                    <img src="images/about-img-new-2.png">
                </div>
            </div>
            <div class="col-sm-6">
                <div class="about-who-txt">
                    <h2 class="wow fadeInLeft" data-wow-duration="2s">Why Should You Choose Our Firm? </h2>
                    <p class="wow fadeInLeft" data-wow-duration="3s">Do you want to increase the number of visitors
                        to your online business? Do you want to redirect them to your e-store? We enable our clients
                        to achieve ground-breaking results with our comprehensive e-commerce, marketing, and Amazon
                        services. </p>
                </div>
                <div class="about-who-ul">
                    <ul>
                        <li class="wow fadeInLeft" data-wow-duartion="2s"> <img src="images/about-icon-new-1.png">
                            <p>20 Years of Experience </p>
                        </li>
                        <li class="wow fadeInLeft" data-wow-duartion="3s"> <img src="images/about-icon-new-2.png">
                            <p>200K+ Happy Customers</p>
                        </li>
                        <li class="wow fadeInLeft" data-wow-duartion="4s"> <img src="images/about-icon-new-3.png">
                            <p>Dedicated Account Managers</p>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="ecom-services about-brn-sec bdr-btm-sec">
    <div class="container">
        <div cass="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-duration="2s">Make Your Product Perform Better with Us</h2>
                    <p class="wow fadeInUp" data-wow-duration="3s">Are you looking to expand your business outreach
                        over diverse channels? We follow the below-mentioned methodology to keep it seamless for our
                        clients: </p>
                </div>
            </div>
            <div class="col-sm-12 p0">
                <div class="col-sm-4">
                    <div class="ecom-srv-box wow fadeInUp" data-wow-duration="1s">
                        <div class="about-brn-ico-dv">
                            <div class="ecom-cir">
                                <img src="images/about-brnd-icon-1.png">
                            </div>
                            <h3>Approach</h3>
                        </div>
                        <p>We're known for our result-driven strategies in terms of Amazon SEO services. With the
                            support of cutting-edge technology and product listing tactics, we have achieved
                            remarkable success through exponential sales and continued exposure.</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="ecom-srv-box wow fadeInUp" data-wow-duration="2s">
                        <div class="about-brn-ico-dv">
                            <div class="ecom-cir">
                                <img src="images/about-brnd-icon-2.png">
                            </div>
                            <h3>Accomplishment</h3>
                        </div>
                        <p>Amazon Pro 360 is a leading company that promotes your product(s) utilizing Amazon's PPC
                            management services. Our strategic approach helps boost market share and sales while
                            lowering your expense toward advertising.</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="ecom-srv-box wow fadeInUp" data-wow-duration="3s">
                        <div class="about-brn-ico-dv">
                            <div class="ecom-cir">
                                <img src="images/about-brnd-icon-3.png">
                            </div>
                            <h3>Outcome</h3>
                        </div>
                        <p>With the support of outstanding Amazon marketing services, we have assisted many
                            businesses in exponentially increasing sales, profits, and growth.</p>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="amazon_market_sec">
    <div class="">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">Premier Amazon Marketing Services</h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Reach our Amazon marketing company to achieve
                        your online business goals.</p>
                </div>
            </div>
        </div>
        <div class="amazon_market_slider">
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img1.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img2.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img3.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img4.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img5.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img6.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img7.jpg"></div>
            <div class="amazon_market_slid"><img src="images/brand-logo-mm-img8.jpg"></div>
        </div>
    </div>
</section>
<section class="about-history bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-duration="2s">WE ARE THE PROFESSIONALS</h2>
                    <p class="wow fadeInUp" data-wow-duration="3s">Do you want to attract more shoppers and redirect
                        them to your e-store? Our Amazon and e-commerce services can fulfill the same in real-time.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <div class="container-fluid p0">
        <div class="col-sm-12 p0">
            <div class="about-his-slide">
                <div class="ab-history-slider">
                    <div class="main-box-about">
                        <div class="about-his-dte">
                            <h4>1997-2002</h4>
                        </div>
                        <div class="about-his-txt">
                            <p>The year when Amazon Pro 360 was launched and within 4 years transformed into Amazon
                                platform.</p>
                        </div>
                    </div>
                    <div class="main-box-about">
                        <div class="about-his-dte1">
                            <h4>2002-2007</h4>
                        </div>
                        <div class="about-his-txt">
                            <p>We have always kept upgrading ourselves with eCommerce and modern-day Amazon
                                marketing. </p>
                        </div>
                    </div>
                    <div class="main-box-about">
                        <div class="about-his-dte">
                            <h4>2007-2012</h4>
                        </div>
                        <div class="about-his-txt">
                            <p>We kept on evolving in the smartphone era promoting online shopping via a
                                mobile-friendly store for eCommerce.</p>
                        </div>
                    </div>
                    <div class="main-box-about">
                        <div class="about-his-dte1">
                            <h4>2012-2017</h4>
                        </div>
                        <div class="about-his-txt">
                            <p>We have always put clients at the forefront for providing a better user experience
                                and online payment modules.</p>
                        </div>
                    </div>
                    <div class="main-box-about">
                        <div class="about-his-dte">
                            <h4>2017-NOW</h4>
                        </div>
                        <div class="about-his-txt">
                            <p>With the evolution of technology, we have continuously developed ourselves with a
                                never say die attitude. Hence, we have always focused on learning more to provide
                                unique and unmatched services to online customers. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="custom-cta">
    <div class="container">
        <div class="row">
            <div class="col-md-5">
                <div class="custom-cta-text">
                    <h2> "The quality of Amazon Pro 360 is that we assist online business operators and get them the
                        exposure their brand deserves." </h2>
                    <h3>Melanie Joshua </h3>
                    <h4>Lead Amazon Consultant</h4>
                </div>
            </div>
            <div class="col-md-6 col-md-offset-1">
                <div class="custom-cta-img">
                    <img src="images/custom-cta-img1.png">
                    <img src="images/custom-cta-img2.png">
                    <img src="images/custom-cta-img3.png">
                </div>
                <div class="custom-cta-img">
                    <img src="images/custom-cta-img4.png">
                    <img src="images/custom-cta-img5.png">
                    <img src="images/custom-cta-img6.png">
                </div>
                <div class="cta-main-btn wow fadeInUp animated" data-wow-duration="4s" style="visibility: visible; animation-duration: 4s; animation-name: fadeInUp;">
                    <a href="javascript:;" class="get-started get-started-cta ">Get A Quote</a>
                    <a href="tel:866-236-7122" class="call-st-cta callphone">Call US - 866-236-7122</a>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-teach-exprt">

</section>
<section class="about-mang-srv bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-duration="2s">WHY OUR AMAZON SERVICES ARE EXCELLENT?</h2>
                    <p class="wow fadeInUp" data-wow-duration="3s">Our clients love working with us because of our
                        professionalism, guaranteed results, and affordable Amazon marketing services. If you are
                        still not convinced, consider the following statistics:</p>
                </div>
                <div class="mang-srv-ul">
                    <ul>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="1s">
                                <h2><span class="count">350</span> +</h2>
                                <p>Dedicated Amazon<br> Marketing Specialists</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">96</span> %</h2>
                                <p>Unique Client<br> Satisfaction Rate</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">2500</span> +</h2>
                                <p>Daily Visitors<br> to the Store</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">20</span> +</h2>
                                <p>Years of Experience<br> in Industry</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">15</span> +</h2>
                                <p>Data-Driven <br>Strategies</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-12">
                    <div class="banner-btn btn-st ecom-btn-st btn-clr-chng-st wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testi-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                    </h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                        reviews:</p>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="testi-slider-st">
                    <div class="testi-slider">
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/testi-img2.png">
                                <h3>Benjamin Stafford</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I hired them to manage my fashion store on Amazon and they did a
                                            great job with the managing as well as marketing. I am highly
                                            satisfied with their services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/testi-img1.png">
                                <h3>Angie Roberts</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>They handled my Amazon store excellently and their team is highly
                                            responsive. They not only kept us updated about the progress, but
                                            also entertained all the buyer's queries really well. I recommend
                                            their Amazon marketing services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/testi-img3.png">
                                <h3>Stanley Lucas</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I would give them a hundred stars if I could. Their services exceeded
                                            my expectations and the results I got from their services were
                                            exceptional. I am glad that I chose to work with such a professional
                                            agency.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include './components/footer.php'; ?>