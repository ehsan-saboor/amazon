<?php include './components/header.php'; ?>
<section class="serv-banner services-bnr custom-banner custom-banner-4">
        <div class="container">
            <div class="row">
                <div class="col-sm-5">
                    <div class="mbnr-left-txt">
                        <h1 class="wow fadeInUp" data-wow-duration="2s">Inspire Buyers Through Amazon Social Media
                            Marketing</h1>
                        <p class="wow fadeInUp" data-wow-duration="3s">Break out Amazon's restricted marketing and
                            leverage social media marketing to humanize your branding strategy. Build a loyal clientele,
                            enhance visibility, and improve your outreach through exclusive, branded social media
                            content.</p>
                        <div class="col-sm-12">
                            <div class="banner-btn btn-st wow fadeInUp" data-wow-duration="4s">
                                <a href="javascript:;" class="get-started-header  wow fadeInUp"
                                    onclick="setButtonURL();" data-wow-duration="4s">Live Chat</a>
                                <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-7">
                    <div class="banner-side-img my-custom-banner wow zoomIn" data-wow-duration="2s">
                        <img src="images/servcs-bnr-side-img28.png">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about-who-sec serv-pro-sec bdr-btm-sec custom-serv-pro">
        <div class="container">
            <div class="row">
                <div class="col-sm-5 cus-form-main">
                    <div class="custom-form">
                        <form method="post" action="#!">
                            <div class="form-heading">
                                <h3><span>CONTACT </span>FORM</h3>
                                <p>Contact our Amazon experts today and get your products listed on the first page of
                                    Amazon.</p>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="text" name="cn" class="form-control" placeholder="First Name"
                                            required="" onkeypress="return /[a-z]/i.test(event.key)">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="email" name="em" class="form-control" placeholder="Email"
                                            required="">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <input type="tel" id="phone" name="pn" class="form-control"
                                            data-validation="number" placeholder="Phone" required=""
                                            onkeypress="return /[0-9]/i.test(event.key)">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <textarea class="form-control" name="msg" placeholder="Message"></textarea>
                            </div>
                            <div class="form-group agre-buton ">
                                <button type="submit" class="btn custom-btn1">GET A FREE CONSULTATION</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-sm-5 col-sm-offset-1">
                    <div class="about-who-txt">
                        <h4 class="wow fadeInLeft" data-wow-duration="1s">Earn Customer Loyalty </h4>
                        <h2 class="wow fadeInLeft" data-wow-duration="2s">with Amazon SMM!</h2>
                        <p class="wow fadeInLeft" data-wow-duration="3s">Amazon SMM is a tough gig, especially when only
                            minimal branded marketing is permitted. So, why would Amazon do such a thing? The reason is
                            brilliant – yet simple - Amazon strives to keep possession of its customers rather than
                            handing them over to another platform! However, strategic Social Media Marketing allows you
                            to build a loyal consumer base that will return to your store repeatedly rather than selling
                            their loyalty to other brands.</p>
                    </div>
                    <div class="col-sm-12">
                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInUp" data-wow-duration="2s">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="marketing-services-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-10 col-md-offset-1">
                    <div class="marketing-head">
                        <h2>Why You Need to Hire Our Amazon Social Media Marketing Services</h2>
                        <p>SMM services allow you to take advantage of a more proactive marketing approach that helps
                            you:
                        </p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="marketing-box">
                        <div class="ams-head">
                            <h2>01</h2>
                            <h3>Build a Community</h3>
                        </div>
                        <img src="images/ams-arrow.png">
                        <p>Social Media Marketing allows you to influence your buyers through social media by building
                            an engaging branding strategy. You can create a loyal following of potential buyers with
                            social media marketing. When your brand name resonates with your potential clients, you gain
                            visibility that serves to get the due brand recognition!</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="marketing-box">
                        <div class="ams-head">
                            <h2>02</h2>
                            <h3>Form a Meaningful Connection</h3>
                        </div>
                        <img src="images/ams-arrow.png">
                        <p>Our Amazon social media marketing agency can help you establish authority as a go-to brand
                            where buyers can visit to seek meaningful information about the products. With active social
                            media accounts, you are not just a reseller on Amazon; you become a brand leader with a
                            loyal customer base who looks up to you to introduce new market trends.</p>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="marketing-box">
                        <div class="ams-head">
                            <h2>03</h2>
                            <h3>Establish a Loyal Clientele</h3>
                        </div>
                        <img src="images/ams-arrow.png">
                        <p>All the time and effort you put into social media marketing brings you one step closer to
                            attaining your sales goals. With Amazon's social media marketing, you can generate quality
                            traffic and redirect that traffic to your Amazon store. This gives you a good chance of
                            converting visitors into leads; and leads into customers. These followers will consider you
                            an industry leader, leading to higher click-through rates.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="custom-cta">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="custom-cta-text">
                        <h2> "If you want to grow your Amazon store through social media, you can hire social media
                            marketing specialists at Amazon Pro 360 to take your marketing to the next level." </h2>
                        <h3>William Joseph </h3>
                        <h4>VP of Branding Department</h4>
                    </div>
                </div>
                <div class="col-md-6 col-md-offset-1">
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img1.png">
                        <img src="images/custom-cta-img2.png">
                        <img src="images/custom-cta-img3.png">
                    </div>
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img4.png">
                        <img src="images/custom-cta-img5.png">
                        <img src="images/custom-cta-img6.png">
                    </div>
                    <div class="cta-main-btn wow fadeInUp" data-wow-duration="4s">
                        <a href="javascript:;" class="get-started get-started-cta ">Get A Quote</a>
                        <a href="tel:866-236-7122" class="call-st-cta callphone">Call US - 866-236-7122</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about-who-sec serv-pro-sec thnik-srv-sec bdr-btm-sec holistic-sec">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="holistic-head">
                        <p>Shoot Your Sales Up with Our Amazon SMM Services</p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="services-pro-img">
                        <img class="wow zoomIn" data-wow-duration="2s" src="images/holistic-img15.png">

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="about-who-txt about-who-txt-two">
                        <h4 class="wow fadeInRight" data-wow-duration="1s">We offer the best Amazon social media
                            marketing s</h4>
                        <h4 class="wow fadeInRight" data-wow-duration="1s">olutions that deliver excellent results.</h4>
                        <p class="wow fadeInRight" data-wow-duration="3s">Social media marketing is a hybrid method that
                            starts with providing value to your consumers and gradually redirects visitors to make
                            purchases using value-driven content and soft-selling techniques. Our Amazon experts will
                            create a result-oriented Social Media Strategy that incorporates soft-selling strategies,
                            sending high-quality, likely-to-convert leads to your Amazon store!</p>
                        <div class="para-box wow fadeInRight" data-wow-duration="4s">
                            <p>"As a professional Amazon SMM company, we give a blended PR recipe that will add a human
                                touch to your product, what lifestyle it will offer to your potential consumers, and how
                                your product improves their lives – life advice, interesting facts, how- to's, and
                                everything lovely."</p>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInUp" data-wow-duration="2s">
                            <a href="javascript:;" class="get-started ">Ring Our Experts Now</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about-who-sec serv-pro-sec bdr-btm-sec holistic-sec holistic-sec-two">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="about-who-txt about-who-txt-two">
                        <h4 class="wow fadeInLeft" data-wow-duration="1s">Leverage Amazon – The Massive e-tailer – </h4>
                        <h2 class="wow fadeInLeft" data-wow-duration="2s">TO GENERATE MORE SALES </h2>
                        <p class="wow fadeInLeft" data-wow-duration="3s">The more effective your marketing plan is, the
                            more you can grow your consumer base and increase conversions. With such a large number of
                            active sellers on Amazon, it takes more than Amazon SEO to establish a name for yourself, be
                            noticed, and entice customers to purchase from your online store. It takes time for
                            purchasers to come across your products and make a purchase; instead, cultivate an audience
                            that wants to buy directly from you!</p>
                        <div class="para-box wow fadeInRight" data-wow-duration="4s">
                            <p>"When you work with our Amazon social media marketing company, we develop engaging
                                content with accurate and relevant information to answer and remedy frequent consumer
                                issues while redirecting them to your business."</p>
                        </div>
                    </div>
                    <div class="col-sm-12">
                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInUp" data-wow-duration="2s">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="services-pro-img">
                        <img class="wow zoomIn" data-wow-duration="2s" src="images/holistic-img16.png">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="about-mang-srv bdr-btm-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-duration="2s">WHY OUR AMAZON SERVICES ARE EXCELLENT?</h2>
                        <p class="wow fadeInUp" data-wow-duration="3s">Our clients love working with us because of our
                            professionalism, guaranteed results, and affordable Amazon marketing services. If you are
                            still not convinced, consider the following statistics:</p>
                    </div>
                    <div class="mang-srv-ul">
                        <ul>
                            <li>
                                <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="1s">
                                    <h2><span class="count">350</span> +</h2>
                                    <p>Dedicated Amazon<br> Marketing Specialists</p>
                                </div>
                            </li>
                            <li>
                                <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                    <h2><span class="count">96</span> %</h2>
                                    <p>Unique Client<br> Satisfaction Rate</p>
                                </div>
                            </li>
                            <li>
                                <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                    <h2><span class="count">2500</span> +</h2>
                                    <p>Daily Visitors<br> to the Store</p>
                                </div>
                            </li>
                            <li>
                                <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                    <h2><span class="count">20</span> +</h2>
                                    <p>Years of Experience<br> in Industry</p>
                                </div>
                            </li>
                            <li>
                                <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                    <h2><span class="count">15</span> +</h2>
                                    <p>Data-Driven <br>Strategies</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="col-sm-12">
                        <div class="banner-btn btn-st ecom-btn-st btn-clr-chng-st wow fadeInUp" data-wow-delay="400ms">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="testi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                        </h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                            reviews:</p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="testi-slider-st">
                        <div class="testi-slider">
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/testi-img2.png">
                                    <h3>Benjamin Stafford</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I hired them to manage my fashion store on Amazon and they did a
                                                great job with the managing as well as marketing. I am highly
                                                satisfied with their services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/testi-img1.png">
                                    <h3>Angie Roberts</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>They handled my Amazon store excellently and their team is highly
                                                responsive. They not only kept us updated about the progress, but
                                                also entertained all the buyer's queries really well. I recommend
                                                their Amazon marketing services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/testi-img3.png">
                                    <h3>Stanley Lucas</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I would give them a hundred stars if I could. Their services exceeded
                                                my expectations and the results I got from their services were
                                                exceptional. I am glad that I chose to work with such a professional
                                                agency.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php include './components/footer.php'; ?>