<?php include './components/header.php'; ?>
<section class="serv-banner about-bnr testi-bnr-main">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="mbnr-left-txt">
                    <h1 class="wow fadeInUp" data-wow-duration="2s">Client Reviews About Our Services</h1>
                    <p class="wow fadeInUp" data-wow-duration="3s">Amazon Pro 360 has garnered an unparalleled
                        reputation among online store owners with our impeccable store setup, eCommerce marketing,
                        and amazon services. Check out what our clients have to say about us!</p>
                    <div class="banner-btn btn-st  wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
            <div class="col-sm-7">

            </div>
        </div>
    </div>
</section>

<!-- <style>
        .about-mang-srv.bdr-btm-sec {
            background: #fff !important;
            color: #000;

        }

        .about-mang-srv.bdr-btm-sec span {
            color: #000;
        }

        section.about-mang-srv .hd-txt h2 {
            color: #000;
        }

        .hd-txt p {
            color: #000;
        }

        .banner-btn.btn-st a {
            color: #000;
        }

        @media (min-width: 320px) and (max-width: 767px) {
            .mang-srv-ul p {
                height: 50px;
                color: #000;
            }
        }
    </style> -->
<section class="about-mang-srv bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-duration="2s">Why use our Amazon account management services?
                    </h2>
                    <p class="wow fadeInUp" data-wow-duration="3s">With more than 20 years of experience, we’ve
                        maintained an impressive track record of increasing client revenues. Combined with our
                        award-winning and data-driven strategies, we’ve become the trusted choice for Amazon account
                        management services.</p>
                </div>
                <div class="mang-srv-ul">
                    <ul>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="1s">
                                <h2><span class="count">225</span> +</h2>
                                <p>Dedicated Amazon<br>Marketing Specialist</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">95.9</span> %</h2>
                                <p>Unmatched Client<br>Satisfaction</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">2500</span> +</h2>
                                <p>Daily<br>Visitors</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">20</span> +</h2>
                                <p>Years of<br>Experience</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">20</span> +</h2>
                                <p>Data-driven<br>Strategies</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-12">
                    <div class="banner-btn btn-st ecom-btn-st btn-clr-chng-st wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testi-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                    </h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                        reviews:</p>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="testi-slider-st">
                    <div class="testi-slider">
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/testi-img2.png">
                                <h3>Benjamin Stafford</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I hired them to manage my fashion store on Amazon and they did a
                                            great job with the managing as well as marketing. I am highly
                                            satisfied with their services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/testi-img1.png">
                                <h3>Angie Roberts</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>They handled my Amazon store excellently and their team is highly
                                            responsive. They not only kept us updated about the progress, but
                                            also entertained all the buyer's queries really well. I recommend
                                            their Amazon marketing services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/testi-img3.png">
                                <h3>Stanley Lucas</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I would give them a hundred stars if I could. Their services exceeded
                                            my expectations and the results I got from their services were
                                            exceptional. I am glad that I chose to work with such a professional
                                            agency.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include './components/footer.php'; ?>