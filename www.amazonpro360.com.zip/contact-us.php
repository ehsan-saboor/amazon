<?php include './components/header.php'; ?>

<section class="serv-banner about-bnr contact-bnr ecom-bnr">
    <div class="container">
        <div class="row">
            <div class="col-sm-5">
                <div class="mbnr-left-txt">
                    <h1 class="wow fadeInUp" data-wow-duration="2s">Contact Us to Unlock Amazon & E-commerce
                        Success!</h1>
                    <p class="wow fadeInUp" data-wow-duration="3s">Are you looking for top-of-the-line eCommerce and
                        Amazon services? You're at the right place. Talk to our expert consultants today to hire our
                        services amnd for all your concerns.</p>
                    <div class="banner-btn btn-st  wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();" data-wow-duration="4s">Live Chat</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
            <div class="col-sm-7">

                <div class="cotnact-banner-img">
                    <img src="images/contact-girl.png">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="contact-form-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-5 cntct-l-col">
                <div class="cntct-l-side">
                    <h4>Contact Information</h4>
                    <p>Call us now to talk to our experts or leave us an email for a quick response</p>
                    <a href="tel:866-236-7122" class="callphone"><i class="fa fa-phone" aria-hidden="true"></i>
                        866-236-7122</a>
                    <a href="mailto:sales@amazonpro360.com"><i class="fa fa-envelope" aria-hidden="true"></i> <span >sales@amazonpro360.com</span></a>
                </div>
            </div>
            <div class="col-sm-7 cntct-r-col">
                <div class="cntct-r-side">
                    <div class="hd-txt">
                        <h2>Get In Touch</h2>
                    </div>
                    <div id="contactForm">
                        <form class="jform validate" action="#!" method="post">
                            <div class="row">
                                <div class="col-md-12 form-group p0">
                                    <div class="col-md-6 col-sm-12 col-xs-12 ">
                                        <input type="text" name="cn" placeholder="Name" minlength="2" maxlength="60" required="" onkeypress="return /[a-z]/i.test(event.key)">
                                    </div>
                                    <div class="col-md-6 col-sm-12 col-xs-12 r-side 	">
                                        <input type="email" name="em" placeholder="Email" maxlength="60" required="">
                                    </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 phone form-group">
                                    <input type="number" name="pn" placeholder="Phone" minlength="7" maxlength="11" required="" onkeypress="return /[0-9]/i.test(event.key)">
                                </div>

                                <div class="col-md-12 form-group txt-area">
                                    <textarea name="msg" placeholder="Message" minlength="2" maxlength="1000"></textarea>
                                </div>

                                <div class="col-md-12 btn-set-ftr">

                                    <input type="submit" name="submit" class="btn btn-default ybtn ftr-form-btn btn-started" value="Get a Quote">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="about-mang-srv bdr-btm-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-duration="2s">Why use our Amazon account management services?
                    </h2>
                    <p class="wow fadeInUp" data-wow-duration="3s">With more than 20 years of experience, we’ve
                        maintained an impressive track record of increasing client revenues. Combined with our
                        award-winning and data-driven strategies, we’ve become the trusted choice for Amazon account
                        management services.</p>
                </div>
                <div class="mang-srv-ul">
                    <ul>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="1s">
                                <h2><span class="count">225</span> +</h2>
                                <p>Dedicated Amazon<br>Marketing Specialist</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">95.9</span> %</h2>
                                <p>Unmatched Client<br>Satisfaction</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">2500</span> +</h2>
                                <p>Daily<br>Visitors</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="2s">
                                <h2><span class="count">20</span> +</h2>
                                <p>Years of<br>Experience</p>
                            </div>
                        </li>
                        <li>
                            <div class="abt-mng-srv-box wow fadeInUp" data-wow-duration="3s">
                                <h2><span class="count">15</span> +</h2>
                                <p>Data-driven<br>Strategies</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="col-sm-12">
                    <div class="banner-btn btn-st ecom-btn-st btn-clr-chng-st wow fadeInUp" data-wow-delay="400ms">
                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<section class="testi-sec">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="hd-txt">
                    <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                    </h2>
                    <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                        reviews:</p>
                </div>
            </div>
            <div class="col-sm-12">
                <div class="testi-slider-st">
                    <div class="testi-slider">
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                <img loading="lazy" src="images/testi-img2.png">
                                <h3>Benjamin Stafford</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I hired them to manage my fashion store on Amazon and they did a
                                            great job with the managing as well as marketing. I am highly
                                            satisfied with their services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                <img loading="lazy" src="images/testi-img1.png">
                                <h3>Angie Roberts</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>They handled my Amazon store excellently and their team is highly
                                            responsive. They not only kept us updated about the progress, but
                                            also entertained all the buyer's queries really well. I recommend
                                            their Amazon marketing services.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                        <div>
                            <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                <img loading="lazy" src="images/testi-img3.png">
                                <h3>Stanley Lucas</h3>

                                <h5 class="c-testimonial-item__country">

                                </h5>
                                <div class="c-testimonial-item__short-feedback">
                                    <div class="rich-text">
                                        <p>I would give them a hundred stars if I could. Their services exceeded
                                            my expectations and the results I got from their services were
                                            exceptional. I am glad that I chose to work with such a professional
                                            agency.</p>
                                    </div>
                                </div>
                                <div class="c-testimonial-item__clutch">
                                    <div class="c-testimonial-item__clutch-logo"></div>
                                    <div class="c-testimonial-item__clutch-rate">5.0</div>
                                    <div class="c-testimonial-item__clutch-stars">
                                        <ul>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                            <li class="c-testimonial-item__clutch-star active"></li>
                                        </ul>
                                    </div>
                                </div>
                                <a class="c-testimonial-item__read-more read_more" href="javascript:;" target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php include './components/footer.php'; ?>