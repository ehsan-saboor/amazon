<?php include './components/header.php'; ?>
<section class="serv-banner services-bnr ecom-stor-bnr kindle-page-bnr">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    <div class="mbnr-left-txt">
                        <h1 class="wow fadeInUp" data-wow-duration="2s">EXTEND THE REACH OF YOUR STORIES WITH <span>OUR
                                AMAZON KINDLE VELLA EXPERTS</span></h1>
                        <p class="wow fadeInUp" data-wow-duration="3s">With our first-class Amazon Kindle Vella
                            services, you're just a step away from achieving worldwide fame and recognition as a book
                            author. We assist you in publishing serialized stories on the world's largest book
                            publishing platform.</p>
                        <div class="banner-ul">



                        </div>
                        <div class="banner-btn btn-st wow fadeInUp" data-wow-duration="4s">
                            <a href="javascript:;" class="get-started-header  wow fadeInUp" onclick="setButtonURL();"
                                data-wow-duration="4s">Live Chat</a>
                            <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
                <div class="col-sm-4 col-sm-offset-2">
                    <div class="bnr-form-st-kindle">
                        <div class="cus-form-main">
                            <div class="custom-form">
                                <form method="post" action="#!">
                                    <img src="images/kindle-ama-arrow.png" class="kindle-ama-arrow">
                                    <div class="form-heading">
                                        <h3><span>Contact</span> Form</h3>
                                        <p>Contact our amazon experts today and get placed at the first page of amazon.
                                        </p>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="text" name="cn" class="form-control"
                                                    placeholder="First Name" required=""
                                                    onkeypress="return /[a-z]/i.test(event.key)">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="email" name="em" class="form-control" placeholder="Email"
                                                    required="">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <input type="tel" id="phone" name="pn" class="form-control"
                                                    data-validation="number" placeholder="Phone" required=""
                                                    onkeypress="return /[0-9]/i.test(event.key)">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <textarea class="form-control" name="msg" placeholder="Message"></textarea>
                                    </div>
                                    <div class="form-group agre-buton ">
                                        <button type="submit" class="btn custom-btn1">GET A FREE CONSULTATION</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="serv-storefrnt bdr-btm-sec kindle-serv-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-duration="2s">HIRE OUR AMAZON KINDLE VELLA COMPANY</h2>
                        <p class="wow fadeInUp" data-wow-duration="3s">Amazon Pro 360 is a leading Amazon book
                            publishing agency that offers authors top-notch Amazon Kindle Vella solutions. Here's why
                            you need to hire us for Amazon Kindle Vella services:</p>
                    </div>
                </div>
                <div class="col-sm-12 p0">
                    <div class="col-sm-3">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="1s">
                            <div class="srv-strfnt-img">
                                <h4>Book Profile Creation</h4>
                            </div>
                            <p>Get your book registered on Amazon Kindle Vella with the help of our Amazon Kindle Vella
                                books professionals, who assist writers in setting up their Amazon Kindle Vella book
                                profiles.</p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="serv-strfrnt-box ecom-srv-box-3  wow fadeInUp" data-wow-duration="2s">
                            <div class="srv-strfnt-img">
                                <h4>Tags Optimization</h4>
                            </div>
                            <p>We link avid readers to professional and aspirant authors. With our premium Amazon book
                                tags optimization service, you can make your book more visible to potential readers.</p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="3s">
                            <div class="srv-strfnt-img">
                                <h4>Boost Engagement</h4>
                            </div>
                            <p>We assist authors in increasing reader engagement and growing a new audience on their
                                Amazon pages. </p>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="serv-strfrnt-box ecom-srv-box-3  wow fadeInUp" data-wow-duration="2s">
                            <div class="srv-strfnt-img">
                                <h4>Book Features</h4>
                            </div>
                            <p>We can assist you in becoming a top-rated author. Our professionals are experts at
                                promoting books on Kindle Vella online to help you establish a large fan base worldwide.
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-sec-two kindl-about-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="col-sm-5">
                        <div class="services-pro-img">
                            <img class="wow zoomIn" data-wow-duration="2s" src="images/about-kindle-publishing.png"
                                style="visibility: visible; animation-duration: 2s; animation-name: zoomIn;">

                        </div>
                    </div>
                    <div class="col-sm-7">
                        <div class="about-who-txt">
                            <h2 class="wow fadeInRight" data-wow-duration="2s">AMAZON INTRODUCTION VELLA KINDLE</h2>
                            <p class="wow fadeInRight" data-wow-duration="3s">Kindle Vella is a platform that allows
                                authors to serialize and publish their books in installments. It is a platform where
                                stories are cut into chunks and released in intervals, similar to a drama or a TV show,
                                to read books that keep the readers engaged until the conclusion.<br><br>At Amazon Pro
                                360, we have a team of Amazon product experts who understand the Amazon algorithm and
                                optimize the book on the Kindle Vella app, allowing the author's book to be at the top
                                of searchable books.</p>
                        </div>

                        <div class="banner-btn btn-st btn-clr-chng-st wow fadeInRight" data-wow-duration="2s">
                            <a href="javascript:;" class="get-started ">Get a Quote</a>
                            <a href="tel:866-236-7122" class="call-st  w callphone">Call US - 866-236-7122</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_market_sec">
        <div class="">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">Premier Amazon Marketing Services</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Reach our Amazon marketing company to achieve
                            your online business goals.</p>
                    </div>
                </div>
            </div>
            <div class="amazon_market_slider">
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img1.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img2.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img3.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img4.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img5.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img6.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img7.jpg"></div>
                <div class="amazon_market_slid"><img src="images/brand-logo-mm-img8.jpg"></div>
            </div>
        </div>
    </section>
    <section class="why-choose bdr-btm-sec">
        <div class="container">
            <div class="row">
                <div class="why-col-lft why-col-lft-heading">
                    <h3 class="wow fadeInLeft" data-wow-delay="380ms">Things You Need to Know About </h3>
                    <h2 class="wow fadeInLeft" data-wow-delay="400ms">Kindle Vella </h2>
                    <p class="wow fadeInLeft" data-wow-delay="410ms">With the Kindle Vella platform, authors can publish
                        serialized stories, one episode at a time. Readers can explore Kindle Vella stories in the
                        Kindle app. </p>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-6">
                    <div class="why-col-lft">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-1.png">
                                    <div class="why-txt">
                                        <h5>Serialized Stories</h5>
                                        <p>A mobile-first reading experience for readers.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-2.png">
                                    <div class="why-txt">
                                        <h5>Thousands of Authors</h5>
                                        <p>Thousands of authors, thousands of stories.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-3.png">
                                    <div class="why-txt">
                                        <h5>Dozens of Genres</h5>
                                        <p>Extensive collection of stories across dozens of genres and microgenres.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-4.png">
                                    <div class="why-txt">
                                        <h5>Tokens Purchase</h5>
                                        <p>To get access to episodes, readers have to purchase tokens.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="why-col-rgt">
                        <ul>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/why-icon-5.png">
                                    <div class="why-txt">
                                        <h5>Earn Royalties</h5>
                                        <p>Authors earn 50% of the money spent by readers to buy tokens.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-6.png">
                                    <div class="why-txt">
                                        <h5>Free Few Episodes</h5>
                                        <p>Make the readers love your story with the first few free episodes.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/why-icon-7.png">
                                    <div class="why-txt">
                                        <h5>Connect with Readers</h5>
                                        <p>Authors can speak to the readers directly using Author Notes.</p>
                                    </div>
                                </div>
                            </li>
                            <li>
                                <div class="why-li-div wow wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/why-icon-8.png">
                                    <div class="why-txt">
                                        <h5>Readers' Engagement</h5>
                                        <p>Readers can react to the stories by using thumbs up to our faves.</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                        <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                            <h4><span>WANT TO LEARN MORE </span><br>ABOUT KINDLE VELLA?</h4>
                            <p>Get in touch with our consultant(s) today!</p>
                        </div>
                        <div class="why-call-div-st">
                            <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                                <a href="tel:866-236-7122" class="callphone">
                                    <div class="why-img why-1">
                                        <i class="fa fa-phone" aria-hidden="true"></i>
                                    </div>
                                    <p>Call now</p>
                                    866-236-7122
                                </a>
                            </div>
                            <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                                <a href="javascript:;" onclick="setButtonURL();">
                                    <div class="why-img why-2">
                                        <img loading="lazy" src="images/message-img.png">
                                    </div>
                                    <p class="live-height">Live Chat</p>
                                </a>
                                <a href="tel:866-236-7122" class="callphone"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="serv-storefrnt bdr-btm-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-duration="2s">SWHY WORK WITH US?</h2>
                        <p class="wow fadeInUp" data-wow-duration="3s">Hire our Kindle Vella services and witness how
                            your work gets global recognition.</p>
                    </div>
                </div>
                <div class="col-sm-12 p0">
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="1s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon1.png">
                                </div>
                                <h4>Transparent Process</h4>
                            </div>
                            <p>Our work process is transparent, and we keep our clients updated with the progress of the
                                work – at all times.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box ecom-srv-box-3  wow fadeInUp" data-wow-duration="2s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon2.png">
                                </div>
                                <h4>Constant Monitoring</h4>
                            </div>
                            <p>We keep a bird's eye view eye on the analytics to monitor how your episodes are
                                performing on Kindle Vella.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="3s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon3.png">
                                </div>
                                <h4>Fast Turnaround</h4>
                            </div>
                            <p>As soon as you hand over the project to us, the dedicated team starts working on it.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="2s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon4.png">
                                </div>
                                <h4>Experienced Professionals</h4>
                            </div>
                            <p>We have a group of professionals who are well-versed with the rules and regulations of
                                the platform.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box  ecom-srv-box-3 wow fadeInUp" data-wow-duration="3s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon6.png">
                                </div>
                                <h4>Budget-Friendly</h4>
                            </div>
                            <p>Our Kindle Vella publishing service is quite affordable, and every author can benefit
                                from it.</p>
                        </div>
                    </div>
                    <div class="col-sm-4">
                        <div class="serv-strfrnt-box  wow fadeInUp" data-wow-duration="4s">
                            <div class="srv-strfnt-img">
                                <div class="ecom-cir">
                                    <img src="images/ecom-stre-mentor-icon5.png">
                                </div>
                                <h4>100% Satisfaction </h4>
                            </div>
                            <p>Customer satisfaction is our top priority. We provide them with the best experience to
                                ensure 100% satisfaction. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="serv-buss-sol">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-duration="2s">Top Faves on Kindle Vella</h2>
                        <p class="wow fadeInUp" data-wow-duration="3s">Check out the favorite Kindle Vella stories now.
                        </p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="business-sol-slider">
                        <div class="buss-slider-for">
                            <div>
                                <div class="busines-sol-img">
                                    <img class=" wow zoomIn" data-wow-duration="2s"
                                        src="images/business-solution-1.png">
                                </div>
                            </div>
                            <div>
                                <div class="busines-sol-img">
                                    <img src="images/business-solution-1.png">
                                </div>
                            </div>
                            <div>
                                <div class="busines-sol-img">
                                    <img src="images/business-solution-1.png">
                                </div>
                            </div>
                            <div>
                                <div class="busines-sol-img">
                                    <img src="images/business-solution-1.png">
                                </div>
                            </div>
                            <div>
                                <div class="busines-sol-img">
                                    <img src="images/business-solution-1.png">
                                </div>
                            </div>
                        </div>
                        <div class="buss-slider-nav">
                            <div>
                                <div class="business-sol-txt">
                                    <img class=" wow zoomIn" data-wow-duration="2s"
                                        src="images/business-solution-logo-1.png">
                                    <p class=" wow fadeInUp" data-wow-duration="2s">Amazon Pro 360 helped Zalando build
                                        their fashion store on Amazon. The storefront was customized as per the client's
                                        liking, and the store helped them boost online sales. </p>
                                    <div class="banner-btn btn-st  wow fadeInUp" data-wow-duration="3s">
                                        <a href="javascript:;" class="get-started   wow fadeInUp"
                                            data-wow-duration="2s">Get a Quote</a>
                                        <a href="tel:866-236-7122" class="call-st  wow fadeInUp callphone"
                                            data-wow-duration="2s">Call US - 866-236-7122</a>

                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="business-sol-txt">
                                    <img src="images/business-solution-logo-1.png">
                                    <p>After listening to the unique requirements of Zalando Amazon Pro 360 built an
                                        Amazon store for them with optimized listings to help their business generate
                                        more sales and revenue. </p>
                                    <div class="banner-btn btn-st wow fadeInUp" data-wow-delay="400ms">
                                        <a href="javascript:;" class="get-started ">Get a Quote</a>
                                        <a href="tel:866-236-7122" class="call-st callphone">Call US - 866-236-7122</a>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="custom-cta">
        <div class="container">
            <div class="row">
                <div class="col-md-5">
                    <div class="custom-cta-text">
                        <h2> “Content Strategizing is an excellent chance for sellers to market their product benefits.
                            “</h2>
                        <h3>Andrew Hill</h3>
                        <h4>VP OF MARKETING</h4>
                    </div>
                </div>
                <div class="col-md-6 col-md-offset-1">
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img1.png">
                        <img src="images/custom-cta-img2.png">
                        <img src="images/custom-cta-img3.png">
                    </div>
                    <div class="custom-cta-img">
                        <img src="images/custom-cta-img4.png">
                        <img src="images/custom-cta-img5.png">
                        <img src="images/custom-cta-img6.png">
                    </div>
                    <div class="cta-main-btn wow fadeInUp" data-wow-duration="4s"
                        style="visibility: visible; animation-duration: 4s; animation-name: fadeInUp;">
                        <a href="javascript:;" class="get-started get-started-cta ">Get A Quote</a>
                        <a href="tel:866-236-7122" class="call-st-cta callphone">Call US - 866-236-7122</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="amazon_consultancy-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">Why Choose Kindle Vella?</h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Kindle Vella offers fantastic features to improve
                            the author experience and keep readers engaged in exciting stories.</p>
                    </div>
                </div>
            </div>
            <div class="consultancy_slider">
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Excellent Reader Experience</h3>
                        <p>Readers can look for and view the details page for a story and get the first few episodes to
                            read for free.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Interact with Authors </h3>
                        <p>Readers can show their appreciation to the authors and interact with them using Faves and
                            Thumbs Up.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img3.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Start a Story</h3>
                        <p>Authors can start a story and add a few episodes to set the plot upon the journey of success.
                            They can edit or unpublish their stories anytime.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_4">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Publish Episodes</h3>
                        <p>Authors can share their stories by publishing one episode at a time. They can publish,
                            update, delete, add a preview, poll, and update status.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_1">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img1.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Content Guidelines</h3>
                        <p>The platform provides clear guidelines about the content for Kindle Vella. It includes
                            episode content, tags, and author notes.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_2">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img2.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Earn More Money</h3>
                        <p>You can earn 50% money of what the readers spend to purchase the tokens to unlock more
                            episodes of the story.</p>
                    </div>
                </div>
                <div class="consultancy_slid consultancy_slid_3">
                    <div class="consultancy_slider_img">
                        <img src="images/consultancy-slide-img4.png">
                    </div>
                    <div class="consultancy_slid_box">
                        <h3>Detailed Reporting</h3>
                        <p>You can track all the royalty earnings, view story likes, and check the number of reads
                            through the Kindle Vella Dashboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="ecom-sec-new">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="mag-ul-div">
                        <ul>
                            <li class=" wow fadeInUp" data-wow-duration="2s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-1-icon.png">
                                    <p>Get your stories published in episodes!</p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp" data-wow-duration="3s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-2-icon.png">
                                    <p>Kindle Vella experts are ready to publish your stories.</p>
                                </div>
                            </li>
                            <li class=" wow fadeInUp" data-wow-duration="4s">
                                <div class="mag-li-plt-box">
                                    <img src="images/magento-web-inner-3-icon.png">
                                    <p>Continuous monitoring of the analytics.</p>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="cat_2mm">
        <div class="container">
            <div class="col-sm-12">
                <div class="why-rgt-inner-div wow zoomIn" data-wow-duration="4s">
                    <div class="why-in-txt wow zoomIn" data-wow-duration="4s">
                        <h4><span>GET YOUR </span>STORY HEARD!<span></span></h4>
                        <p>One episode at a time. Our Kindle Vella publishing experts will help your work get global
                            recognition. Start now!</p>
                    </div>
                    <div class="why-call-div-st">
                        <div class="call-why-div wow zoomIn" data-wow-duration="4s">
                            <a href="tel:866-236-7122" class="callphone">
                                <div class="why-img why-1">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                </div>
                                <p>Call now</p>
                                866-236-7122
                            </a>
                        </div>
                        <div class="call-why-div wow zoomIn" data-wow-duration="5s">
                            <a href="javascript:;" onclick="setButtonURL();">
                                <div class="why-img why-2">
                                    <img loading="lazy" src="images/message-img.png">
                                </div>
                                <p class="live-height">Live Chat</p>
                            </a>
                            <a href="tel:866-236-7122" class="callphone"></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="testi-sec">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <div class="hd-txt">
                        <h2 class="wow fadeInUp" data-wow-delay="380ms">HEAR WHAT OUR CUSTOMERS HAVE TO SAY ABOUT US
                        </h2>
                        <p class="wow fadeInUp" data-wow-delay="400ms">Out of many, here are some of our customer
                            reviews:</p>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="testi-slider-st">
                        <div class="testi-slider">
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="1s">
                                    <img loading="lazy" src="images/testi-img2.png">
                                    <h3>Benjamin Stafford</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I hired them to manage my fashion store on Amazon and they did a
                                                great job with the managing as well as marketing. I am highly
                                                satisfied with their services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="2s">
                                    <img loading="lazy" src="images/testi-img1.png">
                                    <h3>Angie Roberts</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>They handled my Amazon store excellently and their team is highly
                                                responsive. They not only kept us updated about the progress, but
                                                also entertained all the buyer's queries really well. I recommend
                                                their Amazon marketing services.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                            <div>
                                <div class="testi-box wow fadeInUp" data-wow-duration="3s">
                                    <img loading="lazy" src="images/testi-img3.png">
                                    <h3>Stanley Lucas</h3>

                                    <h5 class="c-testimonial-item__country">

                                    </h5>
                                    <div class="c-testimonial-item__short-feedback">
                                        <div class="rich-text">
                                            <p>I would give them a hundred stars if I could. Their services exceeded
                                                my expectations and the results I got from their services were
                                                exceptional. I am glad that I chose to work with such a professional
                                                agency.</p>
                                        </div>
                                    </div>
                                    <div class="c-testimonial-item__clutch">
                                        <div class="c-testimonial-item__clutch-logo"></div>
                                        <div class="c-testimonial-item__clutch-rate">5.0</div>
                                        <div class="c-testimonial-item__clutch-stars">
                                            <ul>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                                <li class="c-testimonial-item__clutch-star active"></li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="c-testimonial-item__read-more read_more" href="javascript:;"
                                        target="_blank">Read more on Clutch <i class="icon-bt-next"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php include './components/footer.php'; ?>