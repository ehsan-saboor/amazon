var num = 200;
$(window).bind("scroll", function () {
  if ($(window).scrollTop() > num) {
    $(".head_top").addClass("fixed");
  } else {
    $(".head_top").removeClass("fixed");
  }
});
$(function () {
  var url = window.location.pathname;
  var activePage = url.substring(url.lastIndexOf("/") + 1);
  $(".head_top ul li a").each(function () {
    var linkPage = this.href.substring(this.href.lastIndexOf("/") + 1);
    if (activePage == linkPage) {
      $(this).parent().addClass("active");
    }
  });
});
$(".press-news-slider").slick({
  arrows: false,
  dots: false,
  slidesToShow: 2,
  slidesToScroll: 1,
});
$("[data-targetit]").on("click", function (e) {
  $(this).addClass("active");
  $(this).siblings().removeClass("active");
  var target = $(this).data("targetit");
  $("." + target)
    .siblings('[class^="box-"]')
    .hide();
  $("." + target).fadeIn();
  $(".pkg-slider").slick("setPosition");
});
$(".consultancy_slider").slick({
  dots: true,
  autoplay: true,
  infinite: true,
  autoplaySpeed: 2000,
  speed: 3000,
  autoplay: true,
  cssEase: "linear",
  arrows: false,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [{
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 3,
      infinite: true,
      arrows: false,
      dots: false,
    },
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 2
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  },
  ],
});
$(".amazon_market_slider").slick({
  dots: true,
  autoplay: true,
  infinite: true,
  autoplaySpeed: 0,
  speed: 20000,
  autoplay: true,
  cssEase: "linear",
  arrows: false,
  slidesToShow: 7,
  slidesToScroll: 1,
  responsive: [{
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 3,
      infinite: true,
      arrows: false,
      dots: false,
    },
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 2,
      slidesToScroll: 2
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 2,
      slidesToScroll: 1
    }
  },
  ],
});
$(".cl-logo-slider").slick({
  dots: true,
  autoplay: true,
  infinite: true,
  autoplaySpeed: 0,
  speed: 5000,
  autoplay: true,
  cssEase: "linear",
  arrows: false,
  dots: false,
  slidesToShow: 5,
  slidesToScroll: 1,
  responsive: [{
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 3,
      infinite: true,
      arrows: false,
      dots: false,
    },
  },
  {
    breakpoint: 600,
    settings: {
      slidesToShow: 2,
      slidesToScroll: 2
    }
  },
  {
    breakpoint: 480,
    settings: {
      slidesToShow: 1,
      slidesToScroll: 1
    }
  },
  ],
});
$(".buss-slider-for").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  fade: true,
  asNavFor: ".buss-slider-nav",
});
$(".buss-slider-nav").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  asNavFor: ".buss-slider-for",
  dots: false,
});
$(".mentor-for").slick({
  slidesToShow: 1,
  slidesToScroll: 1,
  arrows: false,
  dots: false,
  fade: true,
  asNavFor: ".mentor-nav",
});
$(".mentor-nav").slick({
  slidesToShow: 5,
  autoplay: true,
  autoplaySpeed: 5000,
  cssEase: "linear",
  infinite: true,
  slidesToScroll: 1,
  arrows: true,
  asNavFor: ".mentor-for",
  dots: false,
});
$(".testi-slider").slick({
  dots: true,
  arrows: false,
  infinite: false,
  speed: 300,
  slidesToShow: 3,
  slidesToScroll: 1,
  responsive: [{
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 3,
      infinite: true,
      dots: true,
    },
  },
  {
    breakpoint: 768,
    settings: {
      dots: true,
      autoplay: true,
      autoplaySpeed: 3000,
      speed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
    },
  },
  {
    breakpoint: 480,
    settings: {
      dots: true,
      autoplay: true,
      autoplaySpeed: 3000,
      speed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
    },
  },
  ],
});
$(".ab-history-slider").slick({
  dots: false,
  arrows: false,
  infinite: true,
  autoplay: true,
  autoplaySpeed: 2000,
  speed: 300,
  slidesToShow: 4,
  slidesToScroll: 1,
  responsive: [{
    breakpoint: 1024,
    settings: {
      slidesToShow: 3,
      slidesToScroll: 3,
      infinite: true,
      dots: true,
    },
  },
  {
    breakpoint: 768,
    settings: {
      dots: true,
      autoplay: true,
      autoplaySpeed: 3000,
      speed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
    },
  },
  {
    breakpoint: 480,
    settings: {
      dots: true,
      autoplay: true,
      autoplaySpeed: 3000,
      speed: 2000,
      slidesToShow: 1,
      slidesToScroll: 1,
    },
  },
  ],
});
$(".count").each(function () {
  $(this)
    .prop("Counter", 0)
    .animate({
      Counter: $(this).text()
    }, {
      duration: 10000,
      easing: "swing",
      step: function (now) {
        $(this).text(Math.ceil(now));
      },
    });
});
